# Labo Poker

Site d'entraînement au poker (React + Vite) avec 3 modes (Décisions, Outs & %, Pro 25 bb), un classement en ligne et les pages légales (mentions légales, CGU, confidentialité).

## 1. Avant de publier : complète `src/site.config.js`

| Champ | À mettre |
|---|---|
| `email` | Une adresse que tu consultes (obligatoire : contact + demandes RGPD) |
| `editeur` / `anonyme` | Ton nom, ou `anonyme: true` pour ne pas l'afficher (possible car site non commercial, à condition que ton compte Netlify soit à ton vrai nom) |
| `url` | L'adresse finale du site (étape 5) |
| `majLegal` | La date du jour si tu modifies les textes légaux |

## 2. Tester sur ton PC

Il faut Node.js 22.12 ou plus récent.

```bash
npm install
npm run dev
```

Ouvre l'adresse affichée (http://localhost:5173). Le classement affichera « indisponible » en local : c'est normal, il a besoin de Netlify.

Pour tester le classement en local : `npm install -g netlify-cli` puis `netlify dev`.

## 3. Mettre le code sur GitHub

```bash
git init
git add .
git commit -m "Labo Poker v1"
git branch -M main
git remote add origin https://github.com/TON-PSEUDO/labo-poker.git
git push -u origin main
```

(Crée d'abord le dépôt vide `labo-poker` sur github.com.)

## 4. Publier sur Netlify

1. Va sur app.netlify.com et connecte-toi avec GitHub.
2. **Add new project → Import an existing project → GitHub**, puis choisis `labo-poker`.
3. Les réglages sont lus dans `netlify.toml` : ne change rien et clique **Deploy**.
4. Attends 1 à 2 minutes : le site est en ligne.

À chaque `git push`, Netlify republie le site automatiquement.

> Le glisser-déposer (Netlify Drop) ne convient pas : il ne lance pas la fonction du classement.

## 5. Choisir l'adresse

**Project configuration → General → Change project name** → par ex. `labo-poker` → le site devient `https://labo-poker.netlify.app`. Mets cette adresse dans `url` de `src/site.config.js`, puis `git push`.

## 6. Modérer le classement

Les scores sont stockés dans Netlify Blobs (store `leaderboard`, une entrée par joueur). Pour retirer un pseudo, ouvre ton projet sur Netlify, section **Blobs**, et supprime l'entrée concernée.

## Structure

```
src/poker/        moteur de jeu (évaluateur, ranges, bots, corrigés)
src/pages/        écrans : Décisions, Outs, Pro, Classement, pages légales
src/site.config.js  infos éditeur / hébergeur
netlify/functions/scores.mjs  API du classement (GET / POST / DELETE)
netlify.toml      build, redirections, en-têtes de sécurité
```
