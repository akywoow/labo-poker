// ⚠️ À COMPLÉTER AVANT LA MISE EN LIGNE
// Ces informations alimentent les mentions légales, les CGU et la politique de confidentialité.
export const SITE = {
  nom: "Labo Poker",
  url: "https://labo-poker.netlify.app", // remplace par ton adresse Netlify finale

  // Éditeur (toi). Particulier non professionnel :
  // - anonyme: false → ton nom est affiché
  // - anonyme: true  → seul l'hébergeur est affiché (autorisé par l'art. 1-1, II de la LCEN
  //   pour un site non professionnel, à condition d'avoir donné ton identité exacte à Netlify
  //   lors de la création du compte, et tant que le site n'a aucune activité commerciale)
  editeur: "Hugo Perard",
  anonyme: false,
  email: "contact@exemple.fr", // ⚠️ mets une adresse que tu consultes

  majLegal: "12 octobre 2026", // date de dernière mise à jour des textes légaux

  hebergeur: {
    nom: "Netlify, Inc.",
    adresse: "101 2nd Street, San Francisco, CA 94105, États-Unis",
    site: "https://www.netlify.com",
  },
};
