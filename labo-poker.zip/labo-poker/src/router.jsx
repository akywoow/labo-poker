/* Petit routeur (History API) : évite une dépendance de plus */
import { useSyncExternalStore } from "react";

const EVT = "labo:navigate";
const subscribe = (f) => {
  window.addEventListener("popstate", f);
  window.addEventListener(EVT, f);
  return () => {
    window.removeEventListener("popstate", f);
    window.removeEventListener(EVT, f);
  };
};
export const usePath = () => useSyncExternalStore(subscribe, () => window.location.pathname);

export function navigate(to) {
  if (to === window.location.pathname) return;
  window.history.pushState(null, "", to);
  window.dispatchEvent(new Event(EVT));
  window.scrollTo(0, 0);
}

export function Link({ to, children, ...rest }) {
  return (
    <a
      href={to}
      onClick={(e) => {
        if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
        e.preventDefault();
        navigate(to);
      }}
      {...rest}
    >
      {children}
    </a>
  );
}
