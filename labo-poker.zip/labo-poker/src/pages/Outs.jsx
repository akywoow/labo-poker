import { useState } from "react";
import { genOuts, TOLERANCE } from "../poker/outs.js";
import { handName, pc } from "../poker/core.js";
import { stats, useStats, fresh } from "../poker/stats.js";
import { Card, Hud, ResetButton } from "../components/ui.jsx";

const dec = (x) => String(x).replace(".", ",");

function Stepper({ id, label, value, setValue, max }) {
  const bump = (d) => setValue(String(Math.max(0, Math.min(max, (parseFloat(value) || 0) + d))));
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <div className="stepper">
        <button className="step" type="button" onClick={() => bump(-1)} aria-label="Moins">−</button>
        <input id={id} type="number" inputMode="numeric" min="0" max={max} value={value} onChange={(e) => setValue(e.target.value)} />
        <button className="step" type="button" onClick={() => bump(1)} aria-label="Plus">+</button>
      </div>
    </div>
  );
}

export default function Outs() {
  const S = useStats();
  const [ex, setEx] = useState(genOuts);
  const [outs, setOuts] = useState("8");
  const [pct, setPct] = useState("30");
  const [res, setRes] = useState(null);

  const check = (e) => {
    e.preventDefault();
    if (res) return;
    const go = parseInt(outs, 10), gp = parseFloat(String(pct).replace(",", "."));
    const o = ex.outs.length, P = Math.round(ex.p * 1000) / 10;
    const okO = go === o, okP = Math.abs(gp - P) <= TOLERANCE;
    stats.update((x) => {
      x.o.n++;
      if (okO) x.o.outs++;
      if (okP) x.o.pct++;
      x.o.streak = okO && okP ? x.o.streak + 1 : 0;
    });
    setRes({ go, gp, o, P, okO, okP });
  };
  const next = () => { setEx(genOuts()); setRes(null); };

  const o = res?.o;
  const rule = res && (ex.flop ? (o > 8 ? `${o}×4 − (${o}−8) = ${o * 4 - (o - 8)}%` : `${o}×4 = ${o * 4}%`) : `${o}×2 = ${o * 2}%`);
  const calc = res && (ex.flop ? `1 − (${ex.U - o}/${ex.U} × ${ex.U - o - 1}/${ex.U - 1})` : `${o}/${ex.U}`);
  const Row = ({ label, sub, cards }) => (
    <div className="row">
      <div className="lbl"><small>{label}</small><b>{sub}</b></div>
      <div className="cards">{cards.map((c) => <Card key={c} c={c} />)}</div>
    </div>
  );

  return (
    <section>
      <Hud items={[["Exos", S.o.n], ["Outs justes", S.o.n ? pc(S.o.outs / S.o.n) : "–"], ["% justes", S.o.n ? pc(S.o.pct / S.o.n) : "–"], ["Série", S.o.streak]]} />
      <div className="rows">
        <Row label="Ta main" sub={handName(ex.hv)} cards={ex.hero} />
        <Row label={ex.flop ? "Flop" : "Turn"} sub="" cards={ex.board} />
        <Row label="Adversaire" sub={handName(ex.vv)} cards={ex.vil} />
      </div>
      <form onSubmit={check}>
        <div className="q">
          <Stepper id="inOuts" label="Combien d'outs ?" value={outs} setValue={setOuts} max={30} />
          <Stepper id="inPct" label={ex.flop ? "% de toucher d'ici la river" : "% de toucher à la river"} value={pct} setValue={setPct} max={100} />
        </div>
        {!res && <button className="btn raise next" type="submit">Valider</button>}
      </form>
      {res && (
        <div className="fb">
          <span className={`verdict ${res.okO ? "ok" : "ko"}`}>Outs : {o}{res.okO ? " ✓" : ` (toi ${isNaN(res.go) ? "–" : res.go})`}</span>{" "}
          <span className={`verdict ${res.okP ? "ok" : "ko"}`}>{dec(res.P)}%{res.okP ? " ✓" : ` (toi ${isNaN(res.gp) ? "–" : dec(res.gp)}%)`}</span>
          <div className="outs-list">{ex.outs.map((c) => <Card key={c} c={c} size="sm" />)}</div>
          <p>
            <span className="num">Calcul exact : {calc} = {dec(res.P)}%</span>
            <br />Règle rapide : {rule}. Cartes inconnues : {ex.U} (tu vois la main adverse).
          </p>
          <button className="btn next" onClick={next}>Exo suivant</button>
        </div>
      )}
      <p className="tip">Repère : outs × 4 au flop (2 cartes à venir), outs × 2 au turn. Un % est compté juste à ±{TOLERANCE} points.</p>
      <ResetButton onReset={() => stats.update((x) => { x.o = fresh().o; })} />
    </section>
  );
}
