import { useEffect, useSyncExternalStore } from "react";
import { proStore, T, initPro, resetPro, newProHand, heroAct, heroOptions, posOf, potT, myHandName } from "../poker/pro.js";
import { fmt, pc, signed, STN } from "../poker/core.js";
import { useStats } from "../poker/stats.js";
import { Card, Html, Hud, StreetLog, Table, XY, DecList, ResetButton } from "../components/ui.jsx";

export default function Pro() {
  useSyncExternalStore(proStore.subscribe, proStore.version);
  const S = useStats();
  useEffect(() => { if (!T) initPro(); }, []);
  if (!T) return null;

  const me = T.seats[0], opts = heroOptions(), fb = T.fb;
  const seats = T.seats.map((s, i) => {
    const [x, y, dir] = XY[i];
    return {
      key: i, x, y, dir, pos: posOf(i), tag: s.hero ? null : s.style, name: s.name,
      stack: s.allIn && s.inHand ? "ALL-IN" : fmt(s.stack) + " bb", bet: s.bet ? fmt(s.bet) : null,
      folded: !s.inHand, hero: s.hero, act: !T.over && i === T.turn && s.inHand, dealer: i === T.btn, say: s.say,
      shown: s.inHand && !s.hero && T.show ? s.cards : null, backs: s.inHand && !s.hero && !T.show,
    };
  });

  let sub;
  if (T.over) sub = "Main terminée.";
  else if (opts) {
    sub = opts.toCall > 0 ? `À toi : ${fmt(opts.toCall)} bb à payer, pot ${fmt(potT())} bb.` : `À toi de parler (${STN[T.street]}).`;
    if (T.street > 0) sub += ` Tu as ${myHandName().toLowerCase()}.`;
  } else sub = me.inHand ? "Les bots jouent…" : "Tu t'es couché, la main se termine.";

  return (
    <section>
      <Hud items={[["Mains", S.pro.hands], ["Précision", S.pro.n ? pc(S.pro.ok / S.pro.n) : "–"], ["Gains bb", signed(S.pro.bb)], ["Recaves", S.pro.rebuy]]} />
      <p className="tip">6-max · 25 bb · blindes 0,5/1 + ante BB 1 bb. Bots réguliers : ranges push/fold, 3-bet tapis et bluffs mixés. Le corrigé préflop suit leurs ranges.</p>
      <StreetLog logs={T.logs} />
      <Table seats={seats} board={T.board} pot={fmt(potT())} variant="pro" />
      <div className="spot">
        <div className="cards">{me.cards.map((c) => <Card key={c} c={c} size="lg" />)}</div>
        <p><strong>Main #{T.no} · {posOf(0)} · {fmt(me.stack)} bb</strong>{sub}</p>
      </div>

      {opts && (
        <div className="actions four">
          {["fold", "call", "raise", "allin"].map((a) =>
            opts[a] ? <button key={a} className={`btn ${a}`} onClick={() => heroAct(a)}>{opts[a]}</button> : null,
          )}
        </div>
      )}

      {fb?.type === "dec" && (
        <div className="fb">
          <span className={`verdict ${fb.ok ? "ok" : "ko"}`}>{fb.ok ? "✓ " : "✗ "}{fb.lab}</span>{" "}
          {!fb.ok && <span className="num">Meilleur : {fb.best}</span>}
          <Html as="p" html={fb.why} />
        </div>
      )}
      {fb?.type === "end" && (
        <div className="fb">
          <span className={`verdict ${fb.delta >= 0 ? "ok" : "ko"}`}>{signed(fb.delta)} bb</span>{" "}
          <span className="num">{fb.decs.length ? `${fb.decs.filter((d) => d.ok).length}/${fb.decs.length} bons plays` : "Pas de décision"}</span>
          <p>{fb.txt}</p>
          <DecList decs={fb.decs} />
        </div>
      )}
      {T.over && <button className="btn next" onClick={newProHand}>Main suivante</button>}

      <details>
        <summary>Historique de la session</summary>
        <div className="cats">
          {T.hist.length ? (
            T.hist.map((x) => (
              <div key={x.no}><span>#{x.no} · {x.pos} · {x.k}</span><span>{signed(x.delta)} bb · {x.n ? `${x.ok}/${x.n}` : "–"}</span></div>
            ))
          ) : (
            <div><span>Aucune main terminée</span><span /></div>
          )}
        </div>
        <ResetButton onReset={resetPro} />
      </details>
    </section>
  );
}
