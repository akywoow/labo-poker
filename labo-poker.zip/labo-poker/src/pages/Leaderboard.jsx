import { useEffect, useState } from "react";
import { useBoard, refresh, join, leave } from "../leaderboard.js";
import { pc, signed } from "../poker/core.js";
import { Link } from "../router.jsx";

const MIN = { pro: 20, table: 20, outs: 10 };
const MODES = [["pro", "Pro 25 bb"], ["table", "Décisions"], ["outs", "Outs & %"]];

function metric(r, m) {
  if (m === "pro") { const p = r.p || {}; return p.n >= MIN.pro ? { v: p.ok / p.n, vol: `${p.n} déc. · ${signed(p.bb || 0)} bb`, tb: p.bb || 0 } : null; }
  if (m === "table") { const d = r.d || {}; return d.n >= MIN.table ? { v: d.ok / d.n, vol: `${d.n} déc. · ${d.hands || 0} mains`, tb: d.n } : null; }
  const o = r.o || {};
  return o.n >= MIN.outs ? { v: (o.outs + o.pct) / (2 * o.n), vol: `${o.n} exos · outs ${pc(o.outs / o.n)} · % ${pc(o.pct / o.n)}`, tb: o.n } : null;
}

export default function Leaderboard() {
  const { player, rows, error, status } = useBoard();
  const [mode, setMode] = useState("pro");
  const [pseudo, setPseudo] = useState(player?.pseudo || "");
  const [cgu, setCgu] = useState(false);
  const [busy, setBusy] = useState(false);
  const [confirmLeave, setConfirmLeave] = useState(false);

  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 30000);
    return () => clearInterval(t);
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    await join(pseudo.trim());
    setBusy(false);
  };

  const ranked = (rows || [])
    .map((r) => ({ r, m: metric(r, mode) }))
    .filter((x) => x.m)
    .sort((a, b) => b.m.v - a.m.v || b.m.tb - a.m.tb)
    .slice(0, 100);

  return (
    <section>
      <form className="field lbjoin" onSubmit={submit}>
        <label htmlFor="lb-pseudo">{player ? "Ton pseudo au classement" : "Rejoindre le classement"}</label>
        <div className="stepper">
          <input id="lb-pseudo" className="text" type="text" maxLength={20} placeholder="Ex. RiverKing" value={pseudo} onChange={(e) => setPseudo(e.target.value)} autoComplete="nickname" />
          <button className="btn raise small" type="submit" disabled={busy || pseudo.trim().length < 2 || (!player && !cgu)}>
            {player ? "Modifier" : "Rejoindre"}
          </button>
        </div>
        {!player && (
          <label className="check">
            <input type="checkbox" checked={cgu} onChange={(e) => setCgu(e.target.checked)} />
            <span>J'accepte les <Link to="/cgu">CGU</Link> et j'ai lu la <Link to="/confidentialite">politique de confidentialité</Link>. Mon pseudo et mes statistiques seront visibles publiquement.</span>
          </label>
        )}
        <p className="tip">
          Pas de compte ni d'e-mail : seuls ton pseudo et tes statistiques sont envoyés. N'utilise pas ton vrai nom.
        </p>
      </form>

      {(error || status) && <p className={`notice ${error ? "err" : ""}`} role="status">{error || status}</p>}

      <div className="seg" role="group" aria-label="Classement">
        {MODES.map(([k, l]) => (
          <button key={k} aria-pressed={mode === k} onClick={() => setMode(k)}>{l}</button>
        ))}
      </div>

      <div className="lblist">
        {rows === null ? (
          <p className="tip">Chargement du classement…</p>
        ) : ranked.length === 0 ? (
          <p className="tip">Personne n'est encore classé ici. Il faut {MIN[mode]} {mode === "outs" ? "exercices" : "décisions"} minimum pour apparaître.</p>
        ) : (
          ranked.map((x, i) => (
            <div key={x.r.id} className={`lbrow${x.r.id === player?.id ? " me" : ""}`}>
              <span className="rk">{i + 1}</span>
              <span className="who">
                <b>{x.r.pseudo}{x.r.id === player?.id ? " (toi)" : ""}</b>
                <small>{x.m.vol}</small>
              </span>
              <span className="sc">{pc(x.m.v)}</span>
            </div>
          ))
        )}
      </div>
      <p className="tip">Classé par précision. Minimum 20 décisions (10 exercices pour les outs) pour apparaître. Classement indicatif, sans aucune récompense.</p>

      {player && (
        <div className="danger">
          <button className="reset" onClick={() => (confirmLeave ? (setConfirmLeave(false), leave()) : setConfirmLeave(true))} onBlur={() => setConfirmLeave(false)}>
            {confirmLeave ? "Confirmer : supprimer mes données du classement" : "Quitter le classement et supprimer mes données"}
          </button>
        </div>
      )}
    </section>
  );
}
