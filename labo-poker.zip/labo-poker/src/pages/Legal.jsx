import { SITE } from "../site.config.js";
import { Link } from "../router.jsx";

const H = SITE.hebergeur;
const Mail = () => <a href={`mailto:${SITE.email}`}>{SITE.email}</a>;
const Updated = () => <p className="updated">Dernière mise à jour : {SITE.majLegal}</p>;

export function MentionsLegales() {
  return (
    <article className="legal">
      <h1>Mentions légales</h1>
      <Updated />
      <p>Conformément à l'article 1-1 de la loi n° 2004-575 du 21 juin 2004 pour la confiance dans l'économie numérique (LCEN), voici les informations relatives au site {SITE.nom} ({SITE.url}).</p>

      <h2>Éditeur du site</h2>
      {SITE.anonyme ? (
        <p>Le site est édité à titre non professionnel par un particulier qui a choisi de préserver son anonymat, conformément à l'article 1-1, II de la LCEN. Ses éléments d'identification ont été communiqués à l'hébergeur ci-dessous.</p>
      ) : (
        <p>Le site est édité à titre non professionnel par {SITE.editeur}, particulier.</p>
      )}
      <p>Contact : <Mail /></p>
      <p>Directeur de la publication : {SITE.anonyme ? "l'éditeur du site" : SITE.editeur}.</p>

      <h2>Hébergeur</h2>
      <p>
        {H.nom}<br />
        {H.adresse}<br />
        <a href={H.site} target="_blank" rel="noreferrer">{H.site.replace("https://", "")}</a>
      </p>

      <h2>Nature du site</h2>
      <p>{SITE.nom} est un outil gratuit d'entraînement au poker. Il n'organise aucun jeu d'argent : aucune mise, aucun paiement, aucun gain ni lot. Les « bb » affichées sont des unités de jeu fictives sans aucune valeur. Le site ne contient ni publicité ni lien commercial et n'est lié à aucun opérateur de jeux.</p>

      <h2>Propriété intellectuelle</h2>
      <p>La conception, les textes, le code et les éléments graphiques du site sont la propriété de l'éditeur, sauf mention contraire. Les polices Barlow Condensed et Instrument Sans sont distribuées sous licence SIL Open Font License. Toute reproduction du site, totale ou partielle, sans autorisation est interdite.</p>

      <h2>Signaler un contenu</h2>
      <p>Pour signaler un pseudo inapproprié du classement ou tout contenu illicite, écris à <Mail /> en précisant le pseudo concerné et la raison. Le contenu signalé sera examiné et retiré s'il est manifestement illicite ou contraire aux <Link to="/cgu">CGU</Link>.</p>

      <h2>Données personnelles</h2>
      <p>Voir la <Link to="/confidentialite">politique de confidentialité</Link>.</p>
    </article>
  );
}

export function CGU() {
  return (
    <article className="legal">
      <h1>Conditions générales d'utilisation</h1>
      <Updated />

      <h2>1. Objet</h2>
      <p>Les présentes conditions générales d'utilisation (CGU) encadrent l'accès et l'utilisation du site {SITE.nom}. Utiliser le site, c'est accepter les CGU. Rejoindre le classement nécessite de les accepter expressément.</p>

      <h2>2. Description du service</h2>
      <p>{SITE.nom} propose gratuitement trois exercices d'entraînement au poker Texas Hold'em contre des programmes informatiques (« bots ») : un mode Décisions, un mode Outs &amp; %, un mode Pro à 25 bb, ainsi qu'un classement facultatif.</p>
      <p><strong>Le site n'est pas un site de jeux d'argent.</strong> Aucune somme d'argent n'est misée, aucun paiement n'est demandé et aucun gain, lot ou avantage n'est attribué, y compris aux premiers du classement. Les jetons et « bb » sont fictifs et ne peuvent être ni achetés, ni échangés, ni convertis.</p>

      <h2>3. Accès</h2>
      <p>Le site est accessible gratuitement, sans création de compte, à toute personne disposant d'un accès à Internet. Le poker étant un jeu d'argent lorsqu'il est pratiqué avec des mises, le site est <strong>réservé aux personnes âgées de 18 ans ou plus</strong>.</p>
      <p>L'éditeur peut suspendre, modifier ou fermer tout ou partie du site à tout moment, notamment pour maintenance, sans indemnité.</p>

      <h2>4. Caractère pédagogique et absence de garantie</h2>
      <p>Les corrections, ranges, pourcentages d'équité et explications sont des estimations simplifiées produites par simulation. Elles peuvent contenir des approximations ou des erreurs et ne constituent ni un conseil professionnel, ni une incitation à jouer de l'argent. Les bonnes performances sur le site ne garantissent aucun résultat en jeu réel.</p>

      <h2>5. Classement</h2>
      <p>La participation au classement est facultative. En le rejoignant, tu choisis un pseudo qui sera affiché publiquement avec tes statistiques d'entraînement. Le pseudo ne doit pas :</p>
      <ul>
        <li>contenir ton nom réel ou celui d'une autre personne, ni usurper une identité ;</li>
        <li>être injurieux, haineux, discriminatoire, obscène ou contraire à la loi ;</li>
        <li>faire la promotion d'un site, d'un produit ou d'un opérateur de jeux.</li>
      </ul>
      <p>Les statistiques sont calculées sur ton appareil. Toute manipulation visant à fausser le classement est interdite. L'éditeur peut retirer un pseudo ou un score, sans préavis, en cas de non-respect des CGU ou de résultat manifestement anormal. Le classement est purement indicatif.</p>
      <p>Tu peux quitter le classement à tout moment depuis la page Classement : tes données sont alors supprimées du serveur.</p>

      <h2>6. Jeu responsable</h2>
      <p>Si tu joues aussi en argent réel, garde à l'esprit que jouer comporte des risques : endettement, isolement, dépendance. Pour être aidé, appelle le <a href="tel:+33974751313">09 74 75 13 13</a> (Joueurs Info Service, appel non surtaxé) ou consulte <a href="https://www.joueurs-info-service.fr" target="_blank" rel="noreferrer">joueurs-info-service.fr</a>.</p>

      <h2>7. Responsabilité</h2>
      <p>L'éditeur met en œuvre des moyens raisonnables pour assurer le bon fonctionnement du site, sans garantie de disponibilité continue ni d'absence d'erreur. Les statistiques stockées dans ton navigateur peuvent être perdues si tu effaces les données du site. L'éditeur ne pourra être tenu responsable d'une décision prise sur la base des contenus du site.</p>

      <h2>8. Propriété intellectuelle</h2>
      <p>Le site et ses contenus sont protégés par le droit d'auteur. Ils ne peuvent être reproduits ou réutilisés sans l'accord de l'éditeur, sauf usage personnel et privé.</p>

      <h2>9. Données personnelles</h2>
      <p>Le traitement de tes données est décrit dans la <Link to="/confidentialite">politique de confidentialité</Link>.</p>

      <h2>10. Modification des CGU</h2>
      <p>Les CGU peuvent être modifiées à tout moment. La version applicable est celle en ligne lors de ton utilisation, avec sa date de mise à jour indiquée en haut de page.</p>

      <h2>11. Droit applicable et litiges</h2>
      <p>Les CGU sont soumises au droit français. En cas de difficulté, contacte d'abord l'éditeur à <Mail /> pour trouver une solution amiable. À défaut, les tribunaux français sont compétents, sous réserve des règles d'ordre public applicables aux consommateurs.</p>
    </article>
  );
}

export function Confidentialite() {
  return (
    <article className="legal">
      <h1>Politique de confidentialité</h1>
      <Updated />
      <p>Cette page explique quelles données {SITE.nom} utilise, pourquoi, et comment exercer tes droits, conformément au Règlement général sur la protection des données (RGPD) et à la loi Informatique et Libertés.</p>

      <h2>Responsable du traitement</h2>
      <p>{SITE.anonyme ? "L'éditeur du site" : SITE.editeur}, joignable à <Mail />.</p>

      <h2>En bref</h2>
      <ul>
        <li>Pas de compte, pas d'e-mail demandé, pas de publicité.</li>
        <li>Aucun cookie publicitaire ni outil de mesure d'audience, donc pas de bandeau cookies.</li>
        <li>Polices hébergées sur le site : aucune connexion à Google ou à un autre service tiers.</li>
        <li>Rien n'est envoyé au serveur tant que tu ne rejoins pas le classement.</li>
      </ul>

      <h2>1. Données stockées dans ton navigateur</h2>
      <p>Tes statistiques d'entraînement, ta confirmation d'accès au site et, si tu rejoins le classement, ton identifiant de joueur sont enregistrés dans le stockage local de ton navigateur (localStorage). Ces données restent sur ton appareil et ne servent qu'au fonctionnement du site : elles sont strictement nécessaires au service que tu demandes et ne requièrent donc pas de consentement (article 82 de la loi Informatique et Libertés). Tu peux les effacer à tout moment depuis les réglages de ton navigateur ou avec les boutons « Remettre à zéro ».</p>

      <h2>2. Classement (facultatif)</h2>
      <table>
        <tbody>
          <tr><th scope="row">Données</th><td>Pseudo choisi, statistiques d'entraînement (nombre de décisions, de bons plays, de mains, gains fictifs en bb), identifiant aléatoire, date de dernière mise à jour, date d'acceptation des CGU, empreinte chiffrée d'une clé secrète générée sur ton appareil.</td></tr>
          <tr><th scope="row">Finalité</th><td>Afficher le classement public et mettre à jour tes scores.</td></tr>
          <tr><th scope="row">Base légale</th><td>Exécution des CGU que tu acceptes en rejoignant le classement (art. 6.1.b RGPD).</td></tr>
          <tr><th scope="row">Destinataires</th><td>Le pseudo et les statistiques sont visibles par tous les visiteurs. Les autres données ne sont accessibles qu'à l'éditeur et à l'hébergeur.</td></tr>
          <tr><th scope="row">Durée</th><td>Jusqu'à ce que tu quittes le classement, et au plus 12 mois après ta dernière activité, puis suppression automatique.</td></tr>
        </tbody>
      </table>

      <h2>3. Journaux techniques de l'hébergeur</h2>
      <p>Comme tout hébergeur, {H.nom} enregistre des journaux de connexion (adresse IP, date, page demandée, navigateur) pour assurer la sécurité et le bon fonctionnement du service. Base légale : intérêt légitime à sécuriser le site (art. 6.1.f RGPD). Leur durée de conservation est fixée par l'hébergeur.</p>

      <h2>4. Transfert hors de l'Union européenne</h2>
      <p>Le site est hébergé par {H.nom}, société établie aux États-Unis. Les transferts de données sont encadrés par la certification de Netlify au Data Privacy Framework UE–États-Unis et, à défaut, par les clauses contractuelles types de la Commission européenne, prévues dans l'accord de traitement des données de Netlify.</p>

      <h2>5. Tes droits</h2>
      <p>Tu disposes d'un droit d'accès, de rectification, d'effacement, de limitation, d'opposition et de portabilité de tes données. Le plus simple :</p>
      <ul>
        <li>modifier ton pseudo ou supprimer toutes tes données du classement directement depuis la page <Link to="/classement">Classement</Link> ;</li>
        <li>pour toute autre demande, écrire à <Mail /> en indiquant ton pseudo.</li>
      </ul>
      <p>Une réponse t'est apportée dans un délai d'un mois. Si tu estimes que tes droits ne sont pas respectés, tu peux introduire une réclamation auprès de la CNIL (<a href="https://www.cnil.fr/fr/plaintes" target="_blank" rel="noreferrer">cnil.fr/fr/plaintes</a>).</p>

      <h2>6. Mineurs</h2>
      <p>Le site est réservé aux personnes de 18 ans ou plus. Il ne collecte sciemment aucune donnée concernant des mineurs.</p>
    </article>
  );
}

export function NotFound() {
  return (
    <article className="legal">
      <h1>Page introuvable</h1>
      <p>Cette adresse ne correspond à aucune page. <Link to="/">Retour à l'entraînement</Link>.</p>
    </article>
  );
}
