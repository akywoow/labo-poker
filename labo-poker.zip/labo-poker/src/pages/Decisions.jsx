import { useEffect, useSyncExternalStore } from "react";
import { drillStore, H, POS, newHand, decide, proceed, view, pot } from "../poker/drill.js";
import { fmt, pc, signed } from "../poker/core.js";
import { stats, useStats, fresh } from "../poker/stats.js";
import { Card, Html, Hud, StreetLog, Table, XY, RangeGrid, DecList, ResetButton } from "../components/ui.jsx";

const CATS = { open: "Préflop : open / fold", vsopen: "Préflop : face à une relance", flop: "Flop", turn: "Turn", river: "River" };

export default function Decisions() {
  useSyncExternalStore(drillStore.subscribe, drillStore.version);
  const S = useStats();
  useEffect(() => { if (!H) newHand(); }, []);
  if (!H) return null;

  const v = view(), fb = H.fb;
  const hi = POS.indexOf(H.hero);
  const seats = XY.map(([x, y, dir], i) => {
    const p = POS[(hi + i) % 6], s = H.seats[p];
    const reveal = H.showVil && p === H.vil;
    return {
      key: p, x, y, dir, pos: p, name: s.name, stack: fmt(100 - s.inv) + " bb", bet: s.bet ? fmt(s.bet) : null,
      folded: s.folded, hero: i === 0, act: s.act && !H.over,
      shown: reveal ? H.vc : null, backs: !reveal && !s.folded && i > 0,
    };
  });

  return (
    <section>
      <Hud items={[["Décisions", S.n], ["Précision", S.n ? pc(S.ok / S.n) : "–"], ["Série", S.streak], ["Gains bb", signed(S.bb)]]} />
      <StreetLog logs={H.logs} />
      <Table seats={seats} board={H.board} pot={fmt(pot())} />
      <div className="spot">
        <div className="cards">{H.hc.map((c) => <Card key={c} c={c} size="lg" />)}</div>
        <p><strong>{v.title}</strong>{v.sub}</p>
      </div>

      {!H.over && (
        <div className="actions">
          {["fold", "call", "raise"].map((a) =>
            v.labels[a] ? (
              <button
                key={a}
                className={`btn ${a}${fb?.picked === a ? " picked" : ""}${fb?.set?.[0] === a ? " best" : ""}`}
                disabled={!!fb}
                onClick={() => decide(a)}
              >
                {v.labels[a]}
              </button>
            ) : null,
          )}
        </div>
      )}

      {fb?.type === "dec" && (
        <div className="fb">
          <span className={`verdict ${fb.ok ? "ok" : "ko"}`}>{fb.ok ? "Bon play" : "Erreur"}</span>{" "}
          <span className="num">Meilleur : {fb.set.map((x) => fb.lab[x]).join(" / ")}</span>
          <Html as="p" html={fb.expl} />
          {fb.grid && <RangeGrid grid={fb.grid} me={fb.key} />}
          <button className="btn next" onClick={proceed}>Continuer</button>
        </div>
      )}

      {fb?.type === "end" && (
        <div className="fb">
          <span className={`verdict ${fb.net >= 0 ? "ok" : "ko"}`}>{fb.net > 0 ? "Gagné +" : fb.net < 0 ? "Perdu " : "Égalité "}{fmt(fb.net)} bb</span>{" "}
          <span className="num">{fb.decs.filter((d) => d.ok).length}/{fb.decs.length} bons plays</span>
          <p>{fb.txt}</p>
          <DecList decs={fb.decs} />
          <button className="btn next" onClick={newHand}>Main suivante</button>
        </div>
      )}

      <details>
        <summary>Détail par situation</summary>
        <div className="cats">
          <div><span>Mains jouées</span><span>{S.hands}</span></div>
          {Object.entries(CATS).map(([k, label]) => {
            const [o, n] = S.cat[k];
            return <div key={k}><span>{label}</span><span>{n ? pc(o / n) : "–"} · {o}/{n}</span></div>;
          })}
        </div>
        <ResetButton onReset={() => stats.update((x) => { const f = fresh(); Object.assign(x, { ...f, o: x.o, pro: x.pro }); })} />
      </details>
    </section>
  );
}
