/* Client du classement en ligne. Rien n'est envoyé tant que le joueur n'a pas rejoint. */
import { useSyncExternalStore } from "react";
import { stats } from "./poker/stats.js";

const KEY = "laboPoker.player";
const API = "/api/scores";

const hex = (n) => [...crypto.getRandomValues(new Uint8Array(n))].map((b) => b.toString(16).padStart(2, "0")).join("");
function load() {
  try { return JSON.parse(localStorage.getItem(KEY)) || null; } catch { return null; }
}
let player = load(); // { id, token, pseudo }
let state = { player, rows: null, error: "", status: "" };
const subs = new Set();
const set = (patch) => { state = { ...state, ...patch }; subs.forEach((f) => f()); };
const persist = () => { try { player ? localStorage.setItem(KEY, JSON.stringify(player)) : localStorage.removeItem(KEY); } catch { /* ignore */ } };

export const useBoard = () => useSyncExternalStore((f) => { subs.add(f); return () => subs.delete(f); }, () => state);

const payload = () => {
  const S = stats.get();
  return { d: { n: S.n, ok: S.ok, hands: S.hands, bb: S.bb }, o: { n: S.o.n, outs: S.o.outs, pct: S.o.pct }, p: { hands: S.pro.hands, n: S.pro.n, ok: S.pro.ok, bb: S.pro.bb } };
};

async function call(method, body) {
  const res = await fetch(API, { method, headers: body ? { "content-type": "application/json" } : {}, body: body ? JSON.stringify(body) : undefined });
  let data = {};
  try { data = await res.json(); } catch { /* réponse vide */ }
  if (!res.ok) throw Object.assign(new Error(data.error || "Le serveur ne répond pas."), { status: res.status });
  return data;
}

export async function refresh() {
  try {
    const { rows } = await call("GET");
    set({ rows, error: "" });
  } catch (e) {
    set({ rows: state.rows ?? [], error: e.status ? e.message : "Classement indisponible (il fonctionne une fois le site publié sur Netlify)." });
  }
}

export async function join(pseudo) {
  const p = player ?? { id: crypto.randomUUID(), token: hex(32) };
  try {
    await call("POST", { id: p.id, token: p.token, pseudo, cgu: true, stats: payload() });
    player = { ...p, pseudo };
    persist();
    lastSent = JSON.stringify(payload());
    set({ player, status: "Tu es inscrit au classement. Tes scores s'envoient tout seuls.", error: "" });
    refresh();
    return true;
  } catch (e) {
    set({ error: e.message, status: "" });
    return false;
  }
}

export async function leave() {
  if (!player) return;
  try {
    await call("DELETE", { id: player.id, token: player.token });
    player = null;
    persist();
    set({ player, status: "Tes données ont été supprimées du classement.", error: "" });
    refresh();
  } catch (e) {
    set({ error: e.message });
  }
}

/* envoi automatique, regroupé, quand les stats changent */
let timer = null, lastSent = "";
stats.subscribe(() => {
  if (!player) return;
  clearTimeout(timer);
  timer = setTimeout(async () => {
    const body = JSON.stringify(payload());
    if (body === lastSent || !player) return;
    try {
      await call("POST", { id: player.id, token: player.token, pseudo: player.pseudo, stats: payload() });
      lastSent = body;
    } catch (e) {
      if (e.status === 403 || e.status === 400) { player = null; persist(); set({ player, error: "Ton profil de classement a expiré ou a été supprimé. Tu peux le recréer." }); }
    }
  }, 4000);
});
