import { useEffect, useState } from "react";
import { usePath, Link } from "./router.jsx";
import { SITE } from "./site.config.js";
import Decisions from "./pages/Decisions.jsx";
import Outs from "./pages/Outs.jsx";
import Pro from "./pages/Pro.jsx";
import Leaderboard from "./pages/Leaderboard.jsx";
import { MentionsLegales, CGU, Confidentialite, NotFound } from "./pages/Legal.jsx";

const TABS = [
  ["/", "Décisions", Decisions],
  ["/outs", "Outs & %", Outs],
  ["/pro", "Pro 25 bb", Pro],
  ["/classement", "Classement", Leaderboard],
];
const PAGES = {
  "/mentions-legales": ["Mentions légales", MentionsLegales],
  "/cgu": ["CGU", CGU],
  "/confidentialite": ["Confidentialité", Confidentialite],
};
const GATE_KEY = "laboPoker.gate";

function Gate({ onAccept }) {
  return (
    <div className="gate" role="dialog" aria-modal="true" aria-labelledby="gate-title">
      <div className="gate-box">
        <h2 id="gate-title">Bienvenue sur {SITE.nom}</h2>
        <p>Un outil gratuit pour t'entraîner au poker contre des bots. <strong>Aucun argent réel</strong> : pas de mise, pas de paiement, pas de gain.</p>
        <p>Le site est réservé aux personnes de <strong>18 ans ou plus</strong>. En continuant, tu acceptes les <Link to="/cgu">conditions d'utilisation</Link>.</p>
        <button className="btn raise" onClick={onAccept} autoFocus>J'ai 18 ans ou plus, continuer</button>
        <p className="tip">Tes statistiques restent dans ton navigateur. Aucun cookie publicitaire. <Link to="/confidentialite">Confidentialité</Link></p>
      </div>
    </div>
  );
}

export default function App() {
  const path = usePath().replace(/\/+$/, "") || "/";
  const tab = TABS.find(([p]) => p === path);
  const page = PAGES[path];
  const Comp = tab ? tab[2] : page ? page[1] : NotFound;
  const legalPage = !!page || !tab;

  const [gate, setGate] = useState(() => {
    try { return localStorage.getItem(GATE_KEY) !== "ok"; } catch { return true; }
  });
  const accept = () => {
    try { localStorage.setItem(GATE_KEY, "ok"); } catch { /* navigation privée */ }
    setGate(false);
  };

  useEffect(() => {
    const name = tab ? tab[1] : page ? page[0] : "Page introuvable";
    document.title = path === "/" ? `${SITE.nom} · Entraînement poker` : `${name} · ${SITE.nom}`;
  }, [path, tab, page]);

  return (
    <div className="wrap">
      <a className="skip" href="#contenu">Aller au contenu</a>
      <header>
        <Link to="/" className="brand" aria-label={`${SITE.nom}, accueil`}>Labo <span>Poker</span></Link>
        <nav className="tabs" aria-label="Modes">
          {TABS.map(([p, label]) => (
            <Link key={p} to={p} className="tab" aria-current={p === path ? "page" : undefined}>{label}</Link>
          ))}
        </nav>
      </header>

      <main id="contenu">
        {legalPage && <p className="back"><Link to="/">← Retour à l'entraînement</Link></p>}
        <Comp />
      </main>

      <footer>
        <p className="rg">
          Site d'entraînement gratuit, sans argent réel, réservé aux 18 ans et plus. Jouer comporte des risques : endettement, isolement, dépendance.
          Pour être aidé, appelle le <a href="tel:+33974751313">09 74 75 13 13</a> (appel non surtaxé).
        </p>
        <nav aria-label="Informations légales">
          <Link to="/mentions-legales">Mentions légales</Link>
          <Link to="/cgu">CGU</Link>
          <Link to="/confidentialite">Confidentialité</Link>
          <a href={`mailto:${SITE.email}`}>Contact</a>
        </nav>
        <p className="copy">© {new Date().getFullYear()} {SITE.nom}</p>
      </footer>

      {gate && !legalPage && <Gate onAccept={accept} />}
    </div>
  );
}
