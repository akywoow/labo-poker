/* Briques d'interface communes aux trois modes */
import { useState } from "react";
import { R, SUIT, rankLabel, STN } from "../poker/core.js";

export function Card({ c, size = "" }) {
  return (
    <div className={`card ${size} s${c & 3}`} aria-label={`${rankLabel(c)}${SUIT[c & 3]}`}>
      <b>{rankLabel(c)}</b>
      <i>{SUIT[c & 3]}</i>
    </div>
  );
}

/** Texte généré par le moteur de jeu (jamais par un utilisateur) */
export function Html({ html, as: Tag = "span", ...rest }) {
  return <Tag {...rest} dangerouslySetInnerHTML={{ __html: html }} />;
}

export function Hud({ items }) {
  return (
    <div className="hud">
      {items.map(([label, value]) => (
        <div key={label}>
          <small>{label}</small>
          <b>{value}</b>
        </div>
      ))}
    </div>
  );
}

export function StreetLog({ logs }) {
  return (
    <div className="log" aria-live="polite">
      {logs.map((l, i) =>
        l.length ? (
          <div key={i}>
            <em>{STN[i]}</em> <Html html={l.join(" · ")} />
          </div>
        ) : null,
      )}
    </div>
  );
}

/** Seats : { key, x, y, dir, pos, tag, name, stack, bet, folded, hero, act, dealer, say, shown, backs } */
export function Table({ seats, board, pot, variant = "" }) {
  return (
    <div className="table-wrap">
      <div className={`felt ${variant}`}>
        {seats.map((s) => (
          <div
            key={s.key}
            className={`seat ${s.dir}${s.folded ? " folded" : ""}${s.hero ? " hero" : ""}${s.act ? " act" : ""}`}
            style={{ left: s.x + "%", top: s.y + "%" }}
          >
            {s.dealer && <div className="dbtn" aria-label="Bouton">D</div>}
            {s.shown ? (
              <div className="mini">{s.shown.map((c) => <Card key={c} c={c} size="xs" />)}</div>
            ) : s.backs ? (
              <div className="backs" aria-hidden="true"><span /><span /></div>
            ) : null}
            <div className="pos">
              {s.pos}
              {s.tag && <> <span className="tag">{s.tag}</span></>}
            </div>
            <div className="nm">{s.name}</div>
            <div className="stk">{s.stack}</div>
            {s.say && <div className="say">{s.say}</div>}
            {s.bet ? <div className="bet">{s.bet}</div> : null}
          </div>
        ))}
        <div className="center">
          <div className="board">{board.map((c) => <Card key={c} c={c} size="sm" />)}</div>
          <div className="pot">Pot {pot} bb</div>
        </div>
      </div>
    </div>
  );
}

export const XY = [[50, 100, "down"], [0, 74, "down"], [0, 24, "up"], [50, 0, "up"], [100, 24, "up"], [100, 74, "down"]];

export function RangeGrid({ grid, me }) {
  const cells = [];
  for (let a = 12; a >= 0; a--)
    for (let b = 12; b >= 0; b--) {
      const k = a === b ? R[a] + R[b] : b < a ? R[a] + R[b] + "s" : R[b] + R[a] + "o";
      const cl = grid.r.has(k) ? "r" : grid.c.has(k) ? "c" : "";
      cells.push(<div key={k} className={`${cl}${k === me ? " me" : ""}`}>{k}</div>);
    }
  return (
    <div className="grid-box">
      <div className="grid">{cells}</div>
      <div className="legend">
        <span><i style={{ background: "var(--gold)" }} />Raise / 3-bet</span>
        {grid.c.size > 0 && <span><i style={{ background: "var(--callc)" }} />Call</span>}
        <span><i style={{ background: "var(--panel-2)" }} />Fold</span>
      </div>
    </div>
  );
}

export function DecList({ decs }) {
  if (!decs.length) return null;
  return (
    <div className="declist">
      {decs.map((d, i) => (
        <div key={i} className={d.ok ? "g" : "b"}>
          <span>{d.ok ? "✓" : "✗"} {d.st}</span>
          <span>{d.lab}{d.ok ? "" : ` → ${d.best}`}</span>
        </div>
      ))}
    </div>
  );
}

/** Bouton de remise à zéro avec confirmation intégrée (pas de confirm() natif) */
export function ResetButton({ onReset }) {
  const [armed, setArmed] = useState(false);
  return (
    <button
      className="reset"
      onClick={() => {
        if (!armed) return setArmed(true);
        setArmed(false);
        onReset();
      }}
      onBlur={() => setArmed(false)}
    >
      {armed ? "Confirmer la remise à zéro" : "Remettre à zéro"}
    </button>
  );
}
