/* Cartes, évaluateur de mains, ranges et utilitaires communs */
export const R = "23456789TJQKA";
export const SUIT = ["♠", "♥", "♦", "♣"];
const RN = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "Valet", "Dame", "Roi", "As"];
const CAT = ["Hauteur", "Paire", "Double paire", "Brelan", "Quinte", "Couleur", "Full", "Carré", "Quinte flush"];

export const deck = () => Array.from({ length: 52 }, (_, i) => i);
export function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = (Math.random() * (i + 1)) | 0;
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
export const rnd = (a) => a[(Math.random() * a.length) | 0];
export const rankLabel = (c) => (R[c >> 2] === "T" ? "10" : R[c >> 2]);

export const r1 = (x) => Math.round(x * 10) / 10;
export const fmt = (x) => r1(x).toString().replace(".", ",");
export const pc = (x) => Math.round(x * 100) + "%";
export const signed = (x) => (x > 0 ? "+" : "") + fmt(x);
export const STN = ["Préflop", "Flop", "Turn", "River"];
export const STK = ["pre", "flop", "turn", "river"];
export const union = (...s) => new Set(s.flatMap((x) => [...x]));

/* ---------- évaluateur ---------- */
function topRanks(m, n) {
  const o = [];
  for (let r = 12; r >= 0 && o.length < n; r--) if (m & (1 << r)) o.push(r);
  return o;
}
export function straightHigh(m) {
  for (let h = 12; h >= 4; h--) if (((m >> (h - 4)) & 31) === 31) return h;
  return (m & 0x100f) === 0x100f ? 3 : -1;
}
function score(cat, a) {
  let v = cat;
  for (let i = 0; i < 5; i++) v = v * 16 + ((a[i] ?? -1) + 1);
  return v;
}
export function evalHand(cs) {
  const rc = new Array(13).fill(0), sc = [0, 0, 0, 0], sm = [0, 0, 0, 0];
  let mask = 0;
  for (const c of cs) {
    const r = c >> 2, s = c & 3;
    rc[r]++; sc[s]++; sm[s] |= 1 << r; mask |= 1 << r;
  }
  let fs = -1;
  for (let s = 0; s < 4; s++) if (sc[s] >= 5) fs = s;
  if (fs >= 0) {
    const h = straightHigh(sm[fs]);
    if (h >= 0) return score(8, [h]);
  }
  const q = [], t = [], p = [];
  for (let r = 12; r >= 0; r--) {
    if (rc[r] === 4) q.push(r);
    else if (rc[r] === 3) t.push(r);
    else if (rc[r] === 2) p.push(r);
  }
  if (q.length) return score(7, [q[0], ...topRanks(mask & ~(1 << q[0]), 1)]);
  if (t.length && (t.length > 1 || p.length)) return score(6, [t[0], Math.max(t[1] ?? -1, p[0] ?? -1)]);
  if (fs >= 0) return score(5, topRanks(sm[fs], 5));
  const st = straightHigh(mask);
  if (st >= 0) return score(4, [st]);
  if (t.length) return score(3, [t[0], ...topRanks(mask & ~(1 << t[0]), 2)]);
  if (p.length >= 2) return score(2, [p[0], p[1], ...topRanks(mask & ~(1 << p[0]) & ~(1 << p[1]), 1)]);
  if (p.length) return score(1, [p[0], ...topRanks(mask & ~(1 << p[0]), 3)]);
  return score(0, topRanks(mask, 5));
}
export const catOf = (v) => Math.floor(v / 16 ** 5);
export function handName(v) {
  const c = catOf(v), top = (Math.floor(v / 16 ** 4) % 16) - 1;
  if (c === 1) return "Paire de " + RN[top];
  if (c === 3) return "Brelan de " + RN[top];
  if (c === 0) return "Hauteur " + RN[top];
  return CAT[c];
}

/* ---------- ranges ---------- */
export function handKey(a, b) {
  let x = a >> 2, y = b >> 2;
  if (x < y) [x, y] = [y, x];
  if (x === y) return R[x] + R[y];
  return R[x] + R[y] + ((a & 3) === (b & 3) ? "s" : "o");
}
const I = (ch) => R.indexOf(ch);
export function parse(str) {
  const s = new Set();
  for (let tk of str.split(",")) {
    tk = tk.trim();
    if (!tk) continue;
    if (tk.includes("-")) {
      const [a, b] = tk.split("-");
      if (a[0] === a[1]) {
        const lo = Math.min(I(a[0]), I(b[0])), hi = Math.max(I(a[0]), I(b[0]));
        for (let r = lo; r <= hi; r++) s.add(R[r] + R[r]);
      } else {
        const lo = Math.min(I(a[1]), I(b[1])), hi = Math.max(I(a[1]), I(b[1]));
        for (let r = lo; r <= hi; r++) s.add(a[0] + R[r] + a[2]);
      }
    } else if (tk.endsWith("+")) {
      const x = tk.slice(0, -1);
      if (x[0] === x[1]) for (let r = I(x[0]); r <= 12; r++) s.add(R[r] + R[r]);
      else for (let r = I(x[1]); r < I(x[0]); r++) s.add(x[0] + R[r] + x[2]);
    } else s.add(tk);
  }
  return s;
}
const combos = (k) => (k.length === 2 ? 6 : k[2] === "s" ? 4 : 12);
export const pctRange = (set) => {
  let n = 0;
  set.forEach((k) => (n += combos(k)));
  return n / 1326;
};
export const ALL169 = (() => {
  const s = new Set();
  for (let a = 0; a < 13; a++)
    for (let b = 0; b < 13; b++) s.add(a === b ? R[a] + R[b] : a > b ? R[a] + R[b] + "s" : R[b] + R[a] + "o");
  return s;
})();

/* ---------- lecture de main (utilisée par les bots et le corrigé) ---------- */
export function draws(h, b) {
  if (b.length >= 5) return 0;
  const all = [...h, ...b];
  let fd = false;
  for (let s = 0; s < 4; s++) if (all.filter((c) => (c & 3) === s).length === 4 && h.some((c) => (c & 3) === s)) fd = true;
  let m = 0;
  all.forEach((c) => (m |= 1 << ((c >> 2) + 1)));
  if (m & (1 << 13)) m |= 1;
  let oe = false;
  if (straightHigh(m >> 1) < 0) for (let lo = 0; lo <= 10; lo++) if (((m >> lo) & 15) === 15) oe = true;
  return (fd ? 1 : 0) + (oe ? 1 : 0);
}
export function strength(h, b) {
  const v = evalHand([...h, ...b]), c = catOf(v);
  let s;
  if (c >= 3) s = 0.95;
  else if (c === 2) s = catOf(evalHand(b)) >= 2 ? 0.3 : 0.82;
  else if (c === 1) {
    if (catOf(evalHand(b)) === 1) s = 0.2;
    else {
      const pr = (Math.floor(v / 16 ** 4) % 16) - 1, bmax = Math.max(...b.map((x) => x >> 2));
      s = h[0] >> 2 === h[1] >> 2 ? (pr > bmax ? 0.75 : 0.45) : pr === bmax ? 0.7 : 0.5;
    }
  } else s = 0.12;
  const dr = draws(h, b);
  if (dr) s = Math.max(s, dr > 1 ? 0.6 : 0.45);
  return s;
}

/* ---------- petit store observable pour React ---------- */
export function createStore() {
  let v = 0;
  const subs = new Set();
  return {
    emit() { v++; subs.forEach((f) => f()); },
    subscribe(f) { subs.add(f); return () => subs.delete(f); },
    version: () => v,
  };
}
