/* Statistiques du joueur, gardées dans le navigateur (localStorage) */
import { useSyncExternalStore } from "react";

const KEY = "laboPoker.v2";
export const fresh = () => ({
  n: 0, ok: 0, streak: 0, hands: 0, bb: 0,
  cat: { open: [0, 0], vsopen: [0, 0], flop: [0, 0], turn: [0, 0], river: [0, 0] },
  o: { n: 0, outs: 0, pct: 0, streak: 0 },
  pro: { hands: 0, n: 0, ok: 0, bb: 0, rebuy: 0 },
});

function load() {
  try {
    const x = JSON.parse(localStorage.getItem(KEY));
    if (x && x.cat && x.o) {
      const f = fresh();
      return { ...f, ...x, cat: { ...f.cat, ...x.cat }, o: { ...f.o, ...x.o }, pro: { ...f.pro, ...x.pro } };
    }
  } catch { /* stockage indisponible */ }
  return fresh();
}

let S = load();
const subs = new Set();

export const stats = {
  get: () => S,
  /** fn reçoit une copie modifiable ; les abonnés sont prévenus ensuite */
  update(fn) {
    const next = structuredClone(S);
    fn(next);
    S = next;
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch { /* ignore */ }
    subs.forEach((f) => f());
  },
  subscribe(f) { subs.add(f); return () => subs.delete(f); },
};

export const useStats = () => useSyncExternalStore(stats.subscribe, stats.get);
