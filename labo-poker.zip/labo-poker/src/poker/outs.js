/* Exercices d'outs : tu es derrière, combien de cartes te font passer devant ? */
import { deck, shuffle, evalHand } from "./core.js";

export const TOLERANCE = 2; // écart autorisé en points de %

export function genOuts() {
  for (let t = 0; t < 20000; t++) {
    const d = shuffle(deck());
    const hero = [d[0], d[1]], vil = [d[2], d[3]], n = Math.random() < 0.6 ? 3 : 4;
    const board = d.slice(4, 4 + n), unseen = d.slice(4 + n);
    const hv = evalHand([...hero, ...board]), vv = evalHand([...vil, ...board]);
    if (hv >= vv) continue;
    const outs = unseen.filter((c) => evalHand([...hero, ...board, c]) > evalHand([...vil, ...board, c]));
    const o = outs.length;
    if (o < 2 || o > 17) continue;
    if (o < 6 && Math.random() < 0.7) continue;
    const U = unseen.length;
    const p = n === 3 ? 1 - ((U - o) * (U - o - 1)) / (U * (U - 1)) : o / U;
    return { hero, vil, board, outs: outs.sort((a, b) => b - a), p, U, flop: n === 3, hv, vv };
  }
  return null;
}
