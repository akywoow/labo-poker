/* Mode Décisions : une main complète en tête-à-tête, chaque décision est notée */
import {
  deck, shuffle, rnd, handKey, parse, pctRange, union, evalHand, handName,
  draws, strength, fmt, pc, r1, STN, STK, createStore,
} from "./core.js";
import { stats } from "./stats.js";

export const POS = ["UTG", "HJ", "CO", "BTN", "SB", "BB"];
const PO = ["SB", "BB", "UTG", "HJ", "CO", "BTN"];
const NAMES = ["Ricky", "Mila", "Zed", "Nono", "Sasha", "Kev", "Lulu", "Dimitri", "Yass", "Théo", "Inès", "Max", "Jojo", "Bart"];

export const RFI = {
  UTG: parse("55+,A2s+,KTs+,QTs+,JTs,T9s,98s,AJo+,KQo"),
  HJ: parse("33+,A2s+,K9s+,Q9s+,J9s+,T9s,98s,87s,ATo+,KJo+,QJo"),
  CO: parse("22+,A2s+,K7s+,Q8s+,J8s+,T8s+,97s+,87s,76s,65s,A9o+,KTo+,QTo+,JTo"),
  BTN: parse("22+,A2s+,K2s+,Q5s+,J7s+,T7s+,96s+,85s+,75s+,64s+,54s,A2o+,K8o+,Q9o+,J9o+,T9o,98o"),
  SB: parse("22+,A2s+,K4s+,Q7s+,J7s+,T7s+,97s+,86s+,76s,65s,54s,A5o+,K9o+,QTo+,JTo"),
};
const VS = {
  EP: { tb: parse("QQ+,AKs,AKo,A5s"), call: parse("22-JJ,ATs-AQs,KJs-KQs,QJs,JTs,T9s,98s,AQo") },
  LP: { tb: parse("TT+,AJs+,KQs,AQo+,A5s,A4s"), call: parse("22-99,A2s-ATs,K9s-KJs,Q9s+,J9s+,T8s+,98s,87s,76s,ATo-AJo,KJo+,QJo") },
  BBEP: { tb: parse("QQ+,AKs,AKo,A5s"), call: parse("22-JJ,A2s-AQs,K9s-KQs,Q9s+,J9s+,T8s+,97s+,86s+,76s,65s,54s,ATo-AQo,KTo+,QTo+,JTo") },
  BBLP: { tb: parse("TT+,AJs+,KQs,AQo+,A5s,A4s"), call: parse("22-99,A2s-ATs,K2s-KJs,Q6s+,J7s+,T7s+,96s+,86s+,75s+,65s,54s,A2o-AJo,K9o+,Q9o+,J9o+,T8o+,98o,87o") },
};

export const drillStore = createStore();
export let H = null;
const emit = () => drillStore.emit();

function makeSeats(hero) {
  const nm = shuffle(NAMES.slice()), s = {};
  POS.forEach((p, i) => (s[p] = { name: p === hero ? "Toi" : nm[i], inv: 0, bet: 0, folded: false }));
  s.SB.inv = s.SB.bet = 0.5;
  s.BB.inv = s.BB.bet = 1;
  return s;
}
const after = (a, b) => POS.indexOf(a) < POS.indexOf(b);
function dealHand(filter, prob) {
  let h;
  do { const d = shuffle(deck()); h = [d[0], d[1]]; } while (Math.random() < prob && !filter.has(handKey(h[0], h[1])));
  return h;
}

function genOpen() {
  const hero = rnd(["UTG", "HJ", "CO", "BTN", "SB"]), seats = makeSeats(hero);
  POS.forEach((p) => { if (after(p, hero)) seats[p].folded = true; });
  const cards = dealHand(RFI.BTN, 0.8), k = handKey(...cards), inR = RFI[hero].has(k);
  return {
    type: "open", hero, seats, cards,
    log: POS.filter((p) => after(p, hero)).map((p) => `${p} fold`).join(" · ") || "Tu parles en premier",
    title: "Open ou fold ?", sub: `Tout le monde passe jusqu'à toi, tu es ${hero}.`,
    labels: { fold: "Fold", call: null, raise: hero === "SB" ? "Raise 3" : "Raise 2,5" },
    correct: [inR ? "raise" : "fold"],
    expl: `<b>${k}</b> ${inR ? "fait partie" : "ne fait pas partie"} de la range d'ouverture ${hero} (≈${pc(pctRange(RFI[hero]))} des mains).`,
    grid: { r: RFI[hero], c: new Set() }, key: k,
  };
}
function genVsOpen() {
  const opener = rnd(["UTG", "HJ", "CO", "BTN", "SB"]);
  const hero = rnd(POS.filter((p) => after(opener, p)));
  const seats = makeSeats(hero), size = opener === "SB" ? 3 : 2.5;
  const oi = POS.indexOf(opener), hi = POS.indexOf(hero);
  POS.forEach((p, i) => { if (i < oi || (i > oi && i < hi)) seats[p].folded = true; });
  seats[opener].inv = seats[opener].bet = size;
  seats[opener].act = true;
  const ep = oi <= 1, bb = hero === "BB";
  const R2 = bb ? (ep ? VS.BBEP : VS.BBLP) : ep ? VS.EP : VS.LP;
  const cards = dealHand(union(R2.tb, R2.call), 0.8), k = handKey(...cards);
  const corr = R2.tb.has(k) ? "raise" : R2.call.has(k) ? "call" : "fold";
  const toCall = size - seats[hero].bet;
  const tbSize = after(hero, opener) ? size * 3 : size * 3 + 1;
  const names = { raise: "3-bet", call: "call", fold: "fold" };
  return {
    type: "vsopen", hero, seats, cards, opener, size, tbSize,
    log: POS.slice(0, hi).map((p) => (p === opener ? `<b>${p} raise ${fmt(size)}</b>` : seats[p].folded ? `${p} fold` : "")).filter(Boolean).join(" · "),
    title: "Face à une ouverture", sub: `${opener} relance ${fmt(size)} bb, tu es ${hero}.`,
    labels: { fold: "Fold", call: "Call " + fmt(toCall), raise: "3-bet " + fmt(tbSize) },
    correct: [corr],
    expl: `Contre une ouverture ${ep ? "de début de parole (UTG/HJ)" : "de fin de parole"}, ${bb ? "depuis la BB (1 bb déjà investie, tu défends large), " : ""}<b>${k}</b> se joue en <b>${names[corr]}</b>. 3-bet ≈${pc(pctRange(R2.tb))}, call ≈${pc(pctRange(R2.call))}.`,
    grid: { r: R2.tb, c: R2.call }, key: k,
  };
}

/* comportement du bot adverse */
function pol(kind, s, r) {
  if (kind === "lead") return (s >= 0.65 ? r < 0.8 : s >= 0.4 ? r < 0.4 : r < 0.15) ? "bet" : "check";
  if (kind === "afterCheck") return (s >= 0.65 ? r < 0.9 : s >= 0.4 ? r < 0.5 : r < 0.25) ? "bet" : "check";
  if (kind === "vsBet") return s >= 0.9 && r < 0.35 ? "raise" : s >= 0.45 || r < 0.1 ? "call" : "fold";
  return s >= 0.7 || (s >= 0.45 && r < 0.3) ? "call" : "fold";
}

/* équité contre la range adverse, filtrée par ses actions sur la main */
function eqCalc() {
  const known = new Set([...H.hc, ...H.board]);
  const rest = deck().filter((c) => !known.has(c)), L = rest.length;
  const run = (useHist) => {
    let w = 0, t = 0, n = 0, att = 0;
    while (n < 1500 && att < 80000) {
      att++;
      const a = rest[(Math.random() * L) | 0], b = rest[(Math.random() * L) | 0];
      if (a === b || !H.vr.has(handKey(a, b))) continue;
      if (useHist) {
        let ok = true;
        for (const e of H.hist) if (pol(e.kind, strength([a, b], H.board.slice(0, e.n)), Math.random()) !== e.act) { ok = false; break; }
        if (!ok) continue;
      }
      const bd = H.board.slice();
      while (bd.length < 5) { const c = rest[(Math.random() * L) | 0]; if (c !== a && c !== b && !bd.includes(c)) bd.push(c); }
      const x = evalHand([...H.hc, ...bd]), y = evalHand([a, b, ...bd]);
      if (x > y) w++; else if (x === y) t++;
      n++;
    }
    return n ? { eq: (w + t / 2) / n, n } : { eq: 0.5, n: 0 };
  };
  let r = run(true);
  if (r.n < 150) r = run(false);
  return r.eq;
}

/* ---------- moteur ---------- */
export const pot = () => POS.reduce((a, p) => a + H.seats[p].inv, 0);
const left = (p) => 100 - H.seats[p].inv;
function put(p, amt) {
  const s = H.seats[p];
  amt = Math.max(0, Math.min(amt, 100 - s.inv));
  s.inv += amt; s.bet += amt;
  return amt;
}
const log = (t) => H.logs[H.street].push(t);
const vn = () => H.vil;
const betSize = () => Math.max(1, Math.min(r1(pot() * 0.66), left(H.hero)));

export function newHand() {
  const sp = Math.random() < 0.5 ? genOpen() : genVsOpen();
  H = { pre: sp, hero: sp.hero, seats: sp.seats, hc: sp.cards, board: [], street: 0, mode: "pre", hist: [], dec: [], logs: [[sp.log], [], [], []], over: false, wait: false, fb: null };
  emit();
}
function sampleFrom(set) {
  const ex = new Set(H.hc);
  let a, b;
  do { a = (Math.random() * 52) | 0; b = (Math.random() * 52) | 0; } while (a === b || ex.has(a) || ex.has(b) || !set.has(handKey(a, b)));
  return [a, b];
}
function goHU(vil, vr) {
  H.vil = vil; H.vr = vr; H.vc = sampleFrom(vr);
  const used = new Set([...H.hc, ...H.vc]);
  H.deck = shuffle(deck().filter((c) => !used.has(c)));
  POS.forEach((p) => { if (p !== H.hero && p !== vil) H.seats[p].folded = true; });
  H.heroIP = PO.indexOf(H.hero) > PO.indexOf(vil);
  startStreet(1);
}

function advPre(a) {
  const sp = H.pre, hero = H.hero, S_ = H.seats;
  if (a === "fold") { S_[hero].folded = true; log("Toi fold"); return endHand("vil", "Tu te couches préflop."); }
  if (sp.type === "open") {
    const rs = hero === "SB" ? 3 : 2.5;
    put(hero, rs - S_[hero].bet); log(`<b>Toi raise ${fmt(rs)}</b>`);
    const behind = POS.filter((p) => after(hero, p));
    let caller = null;
    if (Math.random() < 0.78) caller = behind.includes("BB") && Math.random() < 0.7 ? "BB" : rnd(behind);
    behind.forEach((p) => { if (p !== caller) { S_[p].folded = true; log(`${p} fold`); } });
    if (!caller) return endHand("hero", "Tout le monde se couche, tu ramasses les blindes.");
    put(caller, rs - S_[caller].bet); log(`${caller} call`);
    const ep = ["UTG", "HJ"].includes(hero);
    return goHU(caller, caller === "BB" ? (ep ? VS.BBEP : VS.BBLP).call : (ep ? VS.EP : VS.LP).call);
  }
  const op = sp.opener, behind = POS.filter((p) => after(hero, p) && p !== op);
  if (a === "call") { put(hero, sp.size - S_[hero].bet); log("Toi call"); behind.forEach((p) => log(`${p} fold`)); return goHU(op, RFI[op]); }
  put(hero, sp.tbSize - S_[hero].bet); log(`<b>Toi 3-bet ${fmt(sp.tbSize)}</b>`); behind.forEach((p) => log(`${p} fold`));
  if (Math.random() < 0.55) {
    put(op, sp.tbSize - S_[op].bet); log(`${op} call`);
    const strong = union(VS.LP.call, VS.LP.tb, VS.EP.call);
    return goHU(op, new Set([...RFI[op]].filter((k) => strong.has(k))));
  }
  S_[op].folded = true; log(`${op} fold`);
  return endHand("hero", `${op} se couche sur ton 3-bet.`);
}

function startStreet(st) {
  H.street = st;
  POS.forEach((p) => { H.seats[p].bet = 0; H.seats[p].act = false; });
  H.board.push(...H.deck.splice(0, st === 1 ? 3 : 1));
  if (left(H.hero) <= 0 || left(vn()) <= 0) { log("Tapis, on déroule"); return nextStreet(); }
  if (H.heroIP) villainFirst("lead"); else setMode("first");
}
function nextStreet() { if (H.street === 3) return showdown(); startStreet(H.street + 1); }
function setMode(m, toCall) { H.mode = m; H.toCall = toCall || 0; }

function villainFirst(kind) {
  const act = pol(kind, strength(H.vc, H.board), Math.random());
  H.hist.push({ n: H.board.length, kind, act });
  H.seats[vn()].act = true;
  if (act === "bet") {
    const B = put(vn(), Math.max(1, r1(pot() * rnd([0.33, 0.5, 0.75]))));
    log(`<b>${vn()} mise ${fmt(B)}</b>`);
    return setMode("facing", B);
  }
  log(`${vn()} check`);
  if (kind === "lead") return setMode("afterCheck");
  nextStreet();
}
function villainVs(kind) {
  const act = pol(kind, strength(H.vc, H.board), Math.random());
  H.hist.push({ n: H.board.length, kind, act });
  H.seats[vn()].act = true;
  if (act === "fold") { H.seats[vn()].folded = true; log(`${vn()} fold`); return endHand("hero", `${vn()} se couche.`); }
  if (act === "raise") {
    put(vn(), H.seats[H.hero].bet * 3 - H.seats[vn()].bet);
    log(`<b>${vn()} relance à ${fmt(H.seats[vn()].bet)}</b>`);
    return setMode("facingRaise", H.seats[vn()].bet - H.seats[H.hero].bet);
  }
  put(vn(), H.seats[H.hero].bet - H.seats[vn()].bet); log(`${vn()} call`);
  nextStreet();
}

function act(a) {
  const m = H.mode;
  if (m === "pre") return advPre(a);
  if (m === "first" || m === "afterCheck") {
    if (a === "call") { log("Toi check"); return m === "first" ? villainFirst("afterCheck") : nextStreet(); }
    const B = put(H.hero, betSize()); log(`<b>Toi mise ${fmt(B)}</b>`);
    return villainVs("vsBet");
  }
  if (a === "fold") { H.seats[H.hero].folded = true; log("Toi fold"); return endHand("vil", "Tu te couches."); }
  if (a === "call") { put(H.hero, H.toCall); log("Toi call"); return nextStreet(); }
  put(H.hero, H.seats[vn()].bet * 3 - H.seats[H.hero].bet);
  log(`<b>Toi relance à ${fmt(H.seats[H.hero].bet)}</b>`);
  const ans = pol("vsRaise", strength(H.vc, H.board), Math.random());
  H.hist.push({ n: H.board.length, kind: "vsRaise", act: ans });
  if (ans === "fold") { H.seats[vn()].folded = true; log(`${vn()} fold`); return endHand("hero", `${vn()} se couche sur ta relance.`); }
  put(vn(), H.seats[H.hero].bet - H.seats[vn()].bet); log(`${vn()} call`);
  nextStreet();
}

function showdown() {
  const x = evalHand([...H.hc, ...H.board]), y = evalHand([...H.vc, ...H.board]);
  H.showVil = true;
  endHand(x > y ? "hero" : x < y ? "vil" : "split", `Abattage : toi ${handName(x).toLowerCase()}, ${vn()} ${handName(y).toLowerCase()}.`);
}
function endHand(w, txt) {
  H.over = true;
  const P = pot(), net = r1((w === "hero" ? P : w === "split" ? P / 2 : 0) - H.seats[H.hero].inv);
  stats.update((S) => { S.hands++; S.bb = r1(S.bb + net); });
  H.fb = { type: "end", net, txt, decs: H.dec };
}

/* ---------- notation ---------- */
function grade(a) {
  const m = H.mode;
  if (m === "pre") {
    const sp = H.pre;
    return { set: sp.correct, lab: { fold: "Fold", call: "Call", raise: sp.type === "vsopen" ? "3-bet" : "Raise" }, expl: sp.expl, grid: sp.grid, key: sp.key, cat: sp.type };
  }
  const eq = eqCalc(), dr = draws(H.hc, H.board) > 0 && H.street < 3, cat = STK[H.street];
  const mine = handName(evalHand([...H.hc, ...H.board])).toLowerCase();
  const head = `Équité ≈ <b>${pc(eq)}</b> (${mine}) contre les mains que ${vn()} joue de cette façon.`;
  if (m === "first" || m === "afterCheck") {
    let set, why;
    if (eq >= 0.6) { set = ["raise"]; why = "Tu es devant : mise pour la valeur."; }
    else if (eq >= 0.45) { set = ["call", "raise"]; why = "Main moyenne : checker pour contrôler le pot, miser se défend aussi."; }
    else if (dr) { set = ["raise", "call"]; why = "Tirage : un semi-bluff est le meilleur play, checker reste correct."; }
    else { set = ["call"]; why = H.street === 3 ? "Pas assez de valeur et rien à protéger à la river : check." : "Trop faible pour miser sans tirage : check."; }
    return { set, lab: { call: "Check", raise: "Bet" }, expl: `${head} ${why}`, cat };
  }
  const need = H.toCall / (pot() + H.toCall);
  let set, why;
  if (m === "facing" && eq >= 0.7) { set = ["raise", "call"]; why = "Tu domines : relance pour la valeur (suivre reste acceptable)."; }
  else if (eq >= need + 0.03) { set = ["call"]; why = "Ton équité couvre la cote : suivre est rentable."; }
  else if (eq <= need - 0.03) { set = ["fold"]; why = "Pas assez d'équité pour le prix demandé : fold."; }
  else { set = ["call", "fold"]; why = "Spot limite, suivre ou passer se valent."; }
  return { set, lab: { fold: "Fold", call: "Call", raise: "Raise" }, cat, expl: `${head} <span class="num">${fmt(H.toCall)} à payer pour un pot de ${fmt(pot() + H.toCall)} → ${pc(need)} requis.</span> ${why}` };
}

export function decide(a) {
  if (!H || H.over || H.wait) return;
  H.wait = true;
  const g = grade(a), ok = g.set.includes(a);
  stats.update((S) => {
    S.n++;
    if (ok) { S.ok++; S.streak++; } else S.streak = 0;
    S.cat[g.cat][1]++;
    if (ok) S.cat[g.cat][0]++;
  });
  H.dec.push({ st: STN[H.street], ok, lab: g.lab[a], best: g.lab[g.set[0]] });
  H.fb = { type: "dec", ok, picked: a, set: g.set, lab: g.lab, expl: g.expl, grid: g.grid, key: g.key };
  emit();
}
export function proceed() {
  if (!H || !H.fb || H.fb.type !== "dec") return;
  const a = H.fb.picked;
  H.wait = false;
  H.fb = null;
  act(a);
  emit();
}

/* ce que l'écran doit afficher */
export function view() {
  if (H.over) return { title: "Main terminée", sub: H.fb?.txt || "", labels: {} };
  if (H.mode === "pre") return { title: H.pre.title, sub: H.pre.sub, labels: H.pre.labels };
  const st = STN[H.street], mine = handName(evalHand([...H.hc, ...H.board])).toLowerCase();
  const sub = `Tu as ${mine} contre ${vn()} (${H.heroIP ? "tu es en position" : "tu parles en premier"}).`;
  if (H.mode === "facing")
    return { title: `${st} · ${vn()} mise ${fmt(H.toCall)}`, sub, labels: { fold: "Fold", call: "Call " + fmt(H.toCall), raise: left(H.hero) > H.toCall ? "Raise " + fmt(H.seats[vn()].bet * 3) : null } };
  if (H.mode === "facingRaise") return { title: `${st} · ${vn()} relance`, sub, labels: { fold: "Fold", call: "Call " + fmt(H.toCall), raise: null } };
  return { title: `${st} · à toi de parler`, sub, labels: { fold: null, call: "Check", raise: "Bet " + fmt(betSize()) } };
}
