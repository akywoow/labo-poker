/* Mode Pro : table 6-max à 25 bb, bots réguliers, partie continue */
import {
  deck, shuffle, rnd, handKey, parse, pctRange, union, evalHand, handName,
  draws, strength, fmt, pc, r1, STN, ALL169, createStore,
} from "./core.js";
import { stats, fresh } from "./stats.js";

const P6 = ["SB", "BB", "UTG", "HJ", "CO", "BTN"];
const P25 = {
  RFI: {
    UTG: parse("55+,A8s+,KTs+,QTs+,JTs,ATo+,KJo+"),
    HJ: parse("44+,A5s+,K9s+,Q9s+,J9s+,T9s,A9o+,KJo+,QJo"),
    CO: parse("22+,A2s+,K7s+,Q8s+,J8s+,T8s+,98s,87s,A8o+,KTo+,QTo+,JTo"),
    BTN: parse("22+,A2s+,K4s+,Q6s+,J7s+,T7s+,97s+,86s+,76s,65s,A2o+,K8o+,Q9o+,J9o+,T9o"),
    SB: parse("22+,A2s+,K2s+,Q4s+,J6s+,T7s+,97s+,86s+,75s+,65s,54s,A2o+,K7o+,Q9o+,J9o+,T9o"),
  },
  PUSH: {
    UTG: parse("55+,A9s+,KTs+,QJs,ATo+,KQo"),
    HJ: parse("44+,A7s+,K9s+,QTs+,JTs,A9o+,KJo+"),
    CO: parse("22+,A4s+,K8s+,Q9s+,J9s+,T9s,A7o+,KTo+,QJo"),
    BTN: parse("22+,A2s+,K5s+,Q8s+,J8s+,T8s+,98s,A2o+,K9o+,QTo+,JTo"),
    SB: parse("22+,A2s+,K2s+,Q5s+,J7s+,T7s+,97s+,87s,A2o+,K5o+,Q8o+,J9o+,T9o"),
  },
  JAMV: parse("99+,ATs+,AQo+,KQs"), JAMB: parse("A2s-A5s,KJs,QJs,JTs,AJo,KQo,77-88"),
  IPC: parse("22-66,A9s,KTs-KJs,QTs+,JTs,T9s,98s"),
  BBC: parse("22-66,A2s-A9s,K2s-KJs,Q6s+,J7s+,T7s+,96s+,86s+,75s+,64s+,54s,A2o-ATo,K8o+,Q9o+,J9o+,T9o,98o"),
  CST: parse("TT+,AQs+,AKo"), CSL: parse("66+,A9s+,ATo+,KJs+,KQo"), CSB: parse("22+,A2s+,A7o+,K9s+,KTo+,QTs+"),
  CJO: parse("77+,A9s+,ATo+,KQs"), J4: parse("QQ+,AKs,AKo"), C4: parse("TT-JJ,AQs,AJs,KQs,AQo"),
};
const STYLES = [["Reg", 1], ["LAG", 1.7], ["Nit", 0.5], ["Pro", 1.2], ["Reg", 1], ["Shark", 1.4]];
const BOTN = ["AceHunter", "Nitro", "RiverRat", "Klaus", "Mira", "Tilt_Kid", "Vega", "Gr1nd", "DonkKong", "Ozzy", "Lina", "ProbeBet", "Sacha", "Viper", "Nemo", "Blanca"];

export const proStore = createStore();
export let T = null;
const emit = () => proStore.emit();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const posOf = (i) => P6[(i - T.btn - 1 + 12) % 6];
export const potT = () => r1(T.seats.reduce((a, s) => a + s.total, 0) + T.dead);
const live = () => T.seats.filter((s) => s.inHand);
const newBot = () => { const st = rnd(STYLES); return { name: rnd(BOTN), style: st[0], bias: st[1], stack: 25, hero: false }; };

export function initPro() {
  T = { seats: [{ name: "Toi", style: "Toi", bias: 1, stack: 25, hero: true }, newBot(), newBot(), newBot(), newBot(), newBot()], btn: (Math.random() * 6) | 0, no: 0, id: 0, hist: [] };
  newProHand();
}
export function resetPro() {
  stats.update((S) => { S.pro = fresh().pro; });
  initPro();
}

function pcommit(s, amt) {
  amt = r1(Math.max(0, Math.min(amt, s.stack)));
  s.stack = r1(s.stack - amt); s.bet = r1(s.bet + amt); s.total = r1(s.total + amt);
  if (s.stack <= 0) { s.stack = 0; s.allIn = true; }
}
function praiseTo(i, X) {
  const s = T.seats[i];
  X = r1(Math.min(X, s.bet + s.stack));
  if (X <= T.cur) { pcommit(s, T.cur - s.bet); return false; }
  const inc = X - T.cur;
  pcommit(s, X - s.bet);
  if (inc >= T.minR) T.minR = inc;
  T.cur = X; T.raises++; T.aggr = i;
  if (T.first == null) T.first = i;
  T.sAggr.add(i);
  T.seats.forEach((o, j) => { if (j !== i && o.inHand && !o.allIn) o.acted = false; });
  return true;
}

export function newProHand() {
  T.id++; T.over = false; T.show = false; T.heroRes = null; T.fb = null;
  T.seats.forEach((s, i) => {
    if (!s.hero && (s.stack <= 0 || s.stack > 60)) {
      const old = s.name;
      T.seats[i] = newBot();
      T.pendingLog = `${s.stack > 0 ? old + " quitte la table · " : ""}${T.seats[i].name} s'assoit (25 bb)`;
    }
  });
  const me = T.seats[0];
  if (me.stack <= 0) { me.stack = 25; stats.update((S) => { S.pro.rebuy++; }); }
  T.btn = (T.btn + 1) % 6; T.no++;
  const d = shuffle(deck());
  T.seats.forEach((s, i) => Object.assign(s, { cards: [d[2 * i], d[2 * i + 1]], inHand: true, allIn: false, bet: 0, total: 0, acted: false, range: ALL169, say: "" }));
  T.deck = d.slice(12); T.board = []; T.street = 0; T.dead = 0; T.decs = []; T.logs = [[], [], [], []];
  T.raises = 0; T.aggr = null; T.first = null; T.sAggr = new Set();
  T.heroStart = me.stack;
  const sb = T.seats[(T.btn + 1) % 6], bb = T.seats[(T.btn + 2) % 6];
  const ante = r1(Math.min(1, bb.stack));
  bb.stack = r1(bb.stack - ante); T.dead = ante;
  if (bb.stack <= 0) { bb.stack = 0; bb.allIn = true; }
  pcommit(sb, 0.5); pcommit(bb, 1);
  T.cur = 1; T.minR = 1; T.turn = (T.btn + 2) % 6;
  if (T.pendingLog) { T.logs[0].push(T.pendingLog); T.pendingLog = null; }
  emit();
  runPro(T.id);
}

function nextActor() {
  const L = live();
  if (L.length <= 1) return null;
  const na = L.filter((s) => !s.allIn);
  if (na.length === 0) return null;
  if (na.length === 1 && na[0].bet >= T.cur && na[0].acted) return null;
  if (na.length === 1 && na[0].bet >= T.cur && T.street > 0) return null;
  for (let k = 1; k <= 6; k++) {
    const i = (T.turn + k) % 6, s = T.seats[i];
    if (s.inHand && !s.allIn && (!s.acted || s.bet < T.cur - 1e-9)) return i;
  }
  return null;
}

async function runPro(id) {
  while (true) {
    if (id !== T.id) return;
    const i = nextActor();
    if (i === null) { if (await endRound(id)) return; continue; }
    T.turn = i;
    if (T.seats[i].hero) {
      const a = await new Promise((res) => { T.heroRes = res; emit(); });
      if (id !== T.id) return;
      apply(i, a);
    } else {
      emit();
      await sleep(T.seats[0].inHand ? 520 : 200);
      if (id !== T.id) return;
      apply(i, botDecide(i));
    }
    emit();
  }
}
function apply(i, { a, to }) {
  const s = T.seats[i], toCall = r1(T.cur - s.bet), wasOpen = T.cur > 0;
  let say;
  if (a === "fold") { s.inHand = false; say = "Fold"; }
  else if (a === "call") {
    if (toCall <= 0) say = "Check";
    else { pcommit(s, toCall); say = s.allIn ? "Call all-in" : "Call " + fmt(toCall); }
  } else {
    const raised = praiseTo(i, a === "allin" ? s.bet + s.stack : to);
    say = s.allIn ? "All-in " + fmt(s.bet) : raised ? (T.street > 0 && !wasOpen ? "Bet " : "Raise ") + fmt(s.bet) : "Call " + fmt(toCall);
  }
  s.acted = true; s.say = say;
  T.logs[T.street].push(`${s.hero ? "<b>Toi</b>" : posOf(i)} ${say.toLowerCase()}`);
}

async function endRound(id) {
  if (live().length === 1 || T.street === 3) { finish(); return true; }
  if (live().filter((s) => !s.allIn).length <= 1) {
    T.show = true;
    while (T.board.length < 5) {
      T.board.push(...T.deck.splice(0, T.board.length === 0 ? 3 : 1));
      T.street = Math.min(3, T.street + 1);
      emit();
      await sleep(650);
      if (id !== T.id) return true;
    }
    finish();
    return true;
  }
  T.street++;
  T.board.push(...T.deck.splice(0, T.street === 1 ? 3 : 1));
  T.seats.forEach((s) => { s.bet = 0; s.acted = false; s.say = ""; });
  T.cur = 0; T.minR = 1; T.turn = T.btn; T.sAggr = new Set();
  emit();
  await sleep(450);
  return false;
}

function finish() {
  const c = T.seats.map((s) => s.total), lv = [...new Set(c.filter((x) => x > 0))].sort((a, b) => a - b);
  const multi = live().length > 1;
  if (multi) T.show = true;
  const ev = T.seats.map((s) => (s.inHand && multi ? evalHand([...s.cards, ...T.board]) : s.inHand ? 1 : -1));
  const win = new Array(6).fill(0);
  let prev = 0, first = true;
  for (const L of lv) {
    let amt = 0;
    c.forEach((x) => (amt += Math.min(x, L) - Math.min(x, prev)));
    if (first) { amt += T.dead; first = false; }
    let el = [0, 1, 2, 3, 4, 5].filter((i) => T.seats[i].inHand && c[i] >= L - 1e-9);
    if (!el.length) el = [0, 1, 2, 3, 4, 5].filter((i) => T.seats[i].inHand);
    const best = Math.max(...el.map((i) => ev[i])), w = el.filter((i) => ev[i] === best);
    w.forEach((i) => (win[i] += amt / w.length));
    prev = L;
  }
  const parts = [];
  win.forEach((x, i) => {
    if (x > 0) {
      const s = T.seats[i];
      s.stack = r1(s.stack + x);
      parts.push(`${s.hero ? "Toi" : s.name} ${multi ? "(" + handName(ev[i]).toLowerCase() + ") " : ""}gagne ${fmt(x)} bb`);
    }
  });
  T.over = true; T.heroRes = null;
  const me = T.seats[0], delta = r1(me.stack - T.heroStart);
  stats.update((S) => { S.pro.hands++; S.pro.bb = r1(S.pro.bb + delta); });
  T.hist.unshift({ no: T.no, k: handKey(...me.cards), pos: posOf(0), delta, ok: T.decs.filter((d) => d.ok).length, n: T.decs.length });
  T.hist = T.hist.slice(0, 15);
  T.fb = { type: "end", delta, txt: parts.join(" · "), decs: T.decs };
  emit();
}

/* ----- stratégie préflop « pro » : sert aux bots ET de corrigé pour toi ----- */
function solvePre(i) {
  const s = T.seats[i], pos = posOf(i), k = handKey(...s.cards), me = s.bet + s.stack;
  const others = T.seats.filter((o, j) => j !== i && o.inHand).map((o) => o.bet + o.stack);
  const eff = Math.min(me, Math.max(...others));
  const F = { a: "fold", w: 1 }, has = (set) => set.has(k), P = (x) => `≈${pc(pctRange(x))}`;
  if (T.raises === 0) {
    if (pos === "BB")
      return has(P25.JAMV) ? { opts: [{ a: "raise", to: 4, w: 1, rg: P25.JAMV }], why: `Pot limpé : ${k} est assez fort pour relancer en BB.` } : { opts: [{ a: "call", w: 1 }], why: `Pot limpé : check en BB avec ${k}.` };
    if (eff <= 12) {
      const R2 = P25.PUSH[pos];
      return { opts: [has(R2) ? { a: "allin", w: 1, rg: R2 } : F], why: `À ${fmt(eff)} bb effectifs on joue push/fold : range de tapis ${pos} ${P(R2)}, ${k} ${has(R2) ? "est dedans" : "n'y est pas"}.` };
    }
    const R2 = P25.RFI[pos], to = T.cur > 1 ? 3.5 : pos === "SB" ? 2.5 : 2.1;
    return { opts: [has(R2) ? { a: "raise", to, w: 1, rg: R2 } : F], why: `Ouverture ${pos} à 25 bb : ${P(R2)} des mains, ${k} ${has(R2) ? "est dedans → raise " + fmt(to) : "n'y est pas → fold"}.` };
  }
  const rp = posOf(T.aggr), ag = T.seats[T.aggr], shove = ag.allIn || T.cur >= eff * 0.45;
  if (T.raises === 1) {
    if (shove) {
      const R2 = pos === "BB" && rp === "SB" ? P25.CSB : ["CO", "BTN", "SB"].includes(rp) ? P25.CSL : P25.CST;
      return { opts: [has(R2) ? { a: "call", w: 1, rg: R2 } : F], why: `Face au tapis de ${rp}, range de call ${P(R2)} : ${k} ${has(R2) ? "→ call" : "→ fold"}.` };
    }
    const bb = pos === "BB";
    if (has(P25.JAMV)) return { opts: [{ a: "allin", w: 1, rg: union(P25.JAMV, P25.JAMB) }], why: `${k} est dans la range de 3-bet tapis pour la valeur (${P(P25.JAMV)}). À 25 bb on ne 3-bet pas petit.` };
    if (has(P25.JAMB))
      return {
        opts: bb && has(P25.BBC) ? [{ a: "call", w: 0.6, rg: P25.BBC }, { a: "allin", w: 0.4, rg: union(P25.JAMV, P25.JAMB) }] : [{ a: "allin", w: 0.5, rg: union(P25.JAMV, P25.JAMB) }, F],
        why: `${k} est un 3-bet tapis en bluff mixé : tapis ou ${bb ? "call" : "fold"} sont tous les deux corrects.`,
      };
    const C = bb ? P25.BBC : P25.IPC;
    return { opts: [has(C) ? { a: "call", w: 1, rg: C } : F], why: `Face à l'open ${rp} : ${bb ? "la BB défend large (cote + ante)" : "flat serré hors tapis"}, ${k} ${has(C) ? "→ call" : "→ fold"}.` };
  }
  if (shove) {
    const R2 = i === T.first ? P25.CJO : P25.CST;
    return { opts: [has(R2) ? { a: "call", w: 1, rg: R2 } : F], why: `${i === T.first ? "Tu as ouvert et tu prends un tapis : avec la cote tu paies" : "Face à une relance tapis tu paies"} ${P(R2)} des mains, ${k} ${has(R2) ? "→ call" : "→ fold"}.` };
  }
  if (has(P25.J4)) return { opts: [{ a: "allin", w: 1, rg: P25.J4 }], why: `${k} : 4-bet tapis.` };
  if (has(P25.C4)) return { opts: [{ a: "call", w: 1, rg: P25.C4 }], why: `${k} : on paie le 3-bet.` };
  return { opts: [F], why: `${k} est trop faible face à un 3-bet : fold.` };
}

function botDecide(i) {
  const s = T.seats[i];
  if (T.street === 0) {
    const { opts } = solvePre(i);
    const w = opts.map((o) => o.w * ((o.a === "allin" || o.a === "raise") && opts.length > 1 ? s.bias : 1));
    let r = Math.random() * w.reduce((a, b) => a + b, 0), pick = opts[0];
    for (let j = 0; j < opts.length; j++) { r -= w[j]; if (r <= 0) { pick = opts[j]; break; } }
    if (pick.a === "fold" && T.raises === 0 && s.bias > 1.3 && posOf(i) !== "BB" && P25.RFI.BTN.has(handKey(...s.cards)) && Math.random() < 0.15)
      pick = { a: "raise", to: posOf(i) === "SB" ? 2.5 : 2.1, rg: P25.RFI.BTN };
    if (pick.rg) s.range = pick.rg;
    return pick;
  }
  const st = strength(s.cards, T.board), dr = draws(s.cards, T.board) > 0 && T.street < 3;
  const toCall = r1(T.cur - s.bet), P = potT(), r = Math.random(), bf = s.bias, opp = live().length - 1;
  if (toCall <= 0) {
    let bet = false, size = 0.5;
    if (st >= 0.82) { bet = r < 0.75; size = 0.66; }
    else if (st >= 0.65) { bet = r < 0.6; size = 0.5; }
    else if (dr) { bet = r < 0.4 * bf; size = 0.5; }
    else if (st < 0.3 && opp <= 1) { bet = r < 0.2 * bf; size = 0.33; }
    if (!bet) return { a: "call" };
    const amt = r1(Math.max(1, P * size));
    return amt >= s.stack * 0.6 ? { a: "allin" } : { a: "raise", to: amt };
  }
  const need = toCall / (P + toCall);
  let eq = st >= 0.9 ? 0.85 : st >= 0.8 ? 0.7 : st >= 0.65 ? 0.55 : st >= 0.45 ? (T.street === 3 ? 0.2 : 0.36) : st >= 0.3 ? 0.22 : 0.08;
  if (dr) eq = Math.max(eq, T.street === 1 ? 0.35 : 0.2);
  if ((st >= 0.9 && r < 0.4) || (dr && r < 0.07 * bf)) {
    const to = Math.max(T.cur * 3, T.cur + T.minR);
    return to >= (s.stack + s.bet) * 0.5 ? { a: "allin" } : { a: "raise", to };
  }
  if (eq >= need || r < 0.04 * bf) return { a: "call" };
  return { a: "fold" };
}

/* ----- correction de tes décisions ----- */
function eqMulti() {
  const me = T.seats[0], opps = T.seats.map((s, i) => i).filter((i) => i > 0 && T.seats[i].inHand);
  const known = new Set([...me.cards, ...T.board]);
  const rest = deck().filter((c) => !known.has(c)), L = rest.length;
  let share = 0, N = 0;
  for (let it = 0; it < 900; it++) {
    const used = new Set(), hs = [];
    for (const j of opps) {
      let h = null;
      for (let t = 0; t < 80 && !h; t++) {
        const a = rest[(Math.random() * L) | 0], b = rest[(Math.random() * L) | 0];
        if (a === b || used.has(a) || used.has(b) || !T.seats[j].range.has(handKey(a, b))) continue;
        if (T.sAggr.has(j) && !(strength([a, b], T.board) >= 0.45 || Math.random() < 0.3)) continue;
        h = [a, b];
      }
      if (!h) {
        let a, b;
        do { a = rest[(Math.random() * L) | 0]; b = rest[(Math.random() * L) | 0]; } while (a === b || used.has(a) || used.has(b));
        h = [a, b];
      }
      used.add(h[0]); used.add(h[1]); hs.push(h);
    }
    const bd = T.board.slice();
    while (bd.length < 5) { const c = rest[(Math.random() * L) | 0]; if (!used.has(c) && !bd.includes(c)) bd.push(c); }
    const mv = evalHand([...me.cards, ...bd]);
    let best = -1, ties = 0;
    for (const h of hs) { const v = evalHand([...h, ...bd]); if (v > best) { best = v; ties = 0; } if (v === best) ties++; }
    if (mv > best) share += 1; else if (mv === best) share += 1 / (ties + 1);
    N++;
  }
  return { eq: share / N, n: opps.length };
}

function grade(a) {
  const me = T.seats[0], toCall = r1(T.cur - me.bet), callAll = toCall >= me.stack;
  const lab = { fold: "Fold", call: toCall > 0 ? "Call" : "Check", raise: toCall > 0 || T.street === 0 ? "Raise" : "Bet", allin: "All-in" };
  let set, why;
  if (T.street === 0) {
    const sol = solvePre(0);
    set = sol.opts.slice().sort((x, y) => y.w - x.w).map((x) => x.a);
    why = sol.why;
    if (set.includes("allin") && T.heroTo >= me.bet + me.stack) set.push("raise");
  } else {
    const { eq, n } = eqMulti(), P = potT(), dr = draws(me.cards, T.board) > 0 && T.street < 3, low = me.stack <= P;
    const head = `Équité ≈ <b>${pc(eq)}</b> contre ${n > 1 ? n + " adversaires" : "la range adverse"}.`;
    if (toCall <= 0) {
      if (eq >= 0.6) { set = low ? ["allin", "raise"] : ["raise", "allin"]; why = "Tu es devant : mise pour la valeur."; }
      else if (eq >= 0.45) { set = ["call", "raise"]; why = "Main moyenne : check pour contrôler le pot, miser se défend."; }
      else if (dr) { set = ["raise", "call", ...(low ? ["allin"] : [])]; why = "Tirage : le semi-bluff est le meilleur play."; }
      else { set = ["call"]; why = "Trop faible pour miser : check."; }
      why = head + " " + why;
    } else {
      const need = toCall / (P + toCall);
      why = `<span class="num">${fmt(toCall)} pour un pot de ${fmt(P + toCall)} → ${pc(need)} requis.</span> `;
      if (eq >= 0.7) { set = low ? ["allin", "raise", "call"] : ["raise", "allin", "call"]; why += "Tu domines : relance."; }
      else if (eq >= need + 0.03) { set = ["call"]; why += "Le call est rentable."; }
      else if (eq <= need - 0.03) { set = ["fold"]; why += "Pas le prix : fold."; }
      else { set = ["call", "fold"]; why += "Spot limite."; }
      if (callAll && set.includes("call")) set.push("allin");
      why = head + " " + why;
    }
  }
  return { ok: set.includes(a), best: lab[set[0]], lab: lab[a], why };
}

export function heroAct(a) {
  if (!T || !T.heroRes) return;
  const g = grade(a);
  stats.update((S) => { S.pro.n++; if (g.ok) S.pro.ok++; });
  T.decs.push({ st: STN[T.street], ok: g.ok, lab: g.lab, best: g.best });
  T.fb = { type: "dec", ...g };
  const res = T.heroRes;
  T.heroRes = null;
  res(a === "raise" ? { a, to: T.heroTo } : { a });
}

/* boutons proposés au joueur */
export function heroOptions() {
  if (!T || !T.heroRes) return null;
  const me = T.seats[0], toCall = r1(T.cur - me.bet), maxTo = r1(me.bet + me.stack);
  let to;
  if (T.street === 0) to = T.raises === 0 ? (T.cur > 1 ? (posOf(0) === "BB" ? 4 : 3.5) : posOf(0) === "SB" ? 2.5 : 2.1) : r1(T.cur * (T.raises === 1 ? 3 : 2.3));
  else to = toCall <= 0 ? r1(Math.max(1, potT() * 0.66)) : r1(T.cur * 3);
  to = Math.max(to, r1(T.cur + T.minR));
  T.heroTo = to;
  return {
    toCall,
    fold: toCall > 0 ? "Fold" : null,
    call: toCall <= 0 ? "Check" : toCall >= me.stack ? "Call " + fmt(me.stack) : "Call " + fmt(toCall),
    raise: toCall >= me.stack || to >= maxTo * 0.9 ? null : (toCall > 0 || T.street === 0 ? "Raise " : "Bet ") + fmt(to),
    allin: toCall >= me.stack ? null : "All-in " + fmt(maxTo),
  };
}
export const myHandName = () => handName(evalHand([...T.seats[0].cards, ...T.board]));
