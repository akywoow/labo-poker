// API du classement : GET (lire), POST (envoyer ses scores), DELETE (supprimer ses données)
// Stockage : Netlify Blobs (inclus dans Netlify, aucune base de données à configurer)
import { getStore } from "@netlify/blobs";

const MAX_BODY = 4096;
const RETENTION_MS = 365 * 24 * 3600 * 1000; // 12 mois d'inactivité → suppression
const MIN_INTERVAL_MS = 3000;
const ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const TOKEN_RE = /^[0-9a-f]{64}$/;
const PSEUDO_RE = /^[\p{L}\p{N}][\p{L}\p{N} _.\-]{1,19}$/u;
// Filtre basique : la modération manuelle reste possible (CGU)
const BAN_LONG = ["connard", "salope", "encul", "batard", "bougnoul", "youpin", "tapette", "negre", "nazi", "hitler", "porno", "ntamere", "tamere", "moderat", "labopoker"];
const BAN_SHORT = ["pd", "fdp", "ntm", "tg", "cul", "bite", "sexe", "ss", "kkk", "pute", "putes", "nique", "admin"];

let cache = null; // { at, rows } — limite les lectures quand beaucoup de monde consulte

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

async function sha256(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function pseudoProblem(raw) {
  const p = String(raw ?? "").trim().replace(/\s+/g, " ");
  if (!PSEUDO_RE.test(p)) return "Pseudo : 2 à 20 caractères, lettres, chiffres, espace, point, tiret ou _.";
  const flat = p.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[0@]/g, "o").replace(/[1!]/g, "i").replace(/3/g, "e").replace(/4/g, "a").replace(/5/g, "s");
  const letters = flat.replace(/[^a-z]/g, "");
  const words = flat.split(/[^a-z]+/).filter(Boolean);
  if (BAN_LONG.some((w) => letters.includes(w)) || words.some((w) => BAN_SHORT.includes(w))) return "Ce pseudo n'est pas accepté. Choisis-en un autre.";
  return null;
}

const int = (x, max = 1e7) => (Number.isInteger(x) && x >= 0 && x <= max ? x : null);
const bb = (x) => (typeof x === "number" && Number.isFinite(x) && Math.abs(x) <= 1e6 ? Math.round(x * 10) / 10 : null);

export function cleanStats(s) {
  if (!s || typeof s !== "object") return null;
  const d = { n: int(s.d?.n), ok: int(s.d?.ok), hands: int(s.d?.hands), bb: bb(s.d?.bb) };
  const o = { n: int(s.o?.n), outs: int(s.o?.outs), pct: int(s.o?.pct) };
  const p = { hands: int(s.p?.hands), n: int(s.p?.n), ok: int(s.p?.ok), bb: bb(s.p?.bb) };
  const all = [...Object.values(d), ...Object.values(o), ...Object.values(p)];
  if (all.some((v) => v === null)) return null;
  if (d.ok > d.n || o.outs > o.n || o.pct > o.n || p.ok > p.n) return null;
  return { d, o, p };
}

async function readAll(store) {
  if (cache && Date.now() - cache.at < 15000) return cache.rows;
  const { blobs } = await store.list();
  const now = Date.now();
  const rows = (
    await Promise.all(
      blobs.slice(0, 2000).map(async ({ key }) => {
        const r = await store.get(key, { type: "json" });
        if (!r) return null;
        if (now - r.t > RETENTION_MS) {
          await store.delete(key);
          return null;
        }
        return { id: key, pseudo: r.pseudo, d: r.d, o: r.o, p: r.p, t: r.t };
      }),
    )
  ).filter(Boolean);
  cache = { at: now, rows };
  return rows;
}

export default async (req) => {
  const store = getStore("leaderboard");

  if (req.method === "GET") {
    try {
      return json({ rows: await readAll(store) });
    } catch {
      return json({ error: "Classement indisponible pour le moment." }, 503);
    }
  }

  if (req.method !== "POST" && req.method !== "DELETE") return json({ error: "Méthode non autorisée." }, 405);

  const text = await req.text();
  if (text.length > MAX_BODY) return json({ error: "Requête trop volumineuse." }, 413);
  let body;
  try { body = JSON.parse(text); } catch { return json({ error: "Requête invalide." }, 400); }
  const { id, token } = body || {};
  if (!ID_RE.test(String(id)) || !TOKEN_RE.test(String(token))) return json({ error: "Identifiant invalide." }, 400);

  const h = await sha256(token);
  const existing = await store.get(id, { type: "json" });
  if (existing && existing.h !== h) return json({ error: "Ce profil appartient à un autre appareil." }, 403);

  if (req.method === "DELETE") {
    await store.delete(id);
    cache = null;
    return json({ ok: true });
  }

  // POST : création ou mise à jour
  if (!existing && body.cgu !== true) return json({ error: "Tu dois accepter les CGU pour rejoindre le classement." }, 400);
  if (existing && Date.now() - existing.t < MIN_INTERVAL_MS) return json({ error: "Trop rapide, réessaie dans un instant." }, 429);
  const problem = pseudoProblem(body.pseudo);
  if (problem) return json({ error: problem }, 400);
  const st = cleanStats(body.stats);
  if (!st) return json({ error: "Statistiques invalides." }, 400);

  const now = Date.now();
  await store.setJSON(id, {
    pseudo: String(body.pseudo).trim().replace(/\s+/g, " "),
    ...st,
    t: now,
    h,
    cgu: existing?.cgu ?? now, // date d'acceptation des CGU
  });
  cache = null;
  return json({ ok: true });
};

export const config = { path: "/api/scores" };
